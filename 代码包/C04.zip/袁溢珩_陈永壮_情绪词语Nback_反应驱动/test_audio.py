# -*- coding: utf-8 -*-
"""虚拟窗口检验首张图片开始音频、持续整组图片、不进入N-back；不代替硬件验证。"""
import json
import wave
import run_experiment as exp
from test_feedback import SimTime, FakeWindow, FakeSound

cfg=exp.load_config()
assert exp.check_audio_duration(cfg)==24.0
for emotion in exp.EMOTIONS:
    path=exp.get_audio_path(emotion)
    with wave.open(str(path),'rb') as snd:
        assert snd.getnframes()/snd.getframerate()==24.0
        assert snd.getnchannels()==2 and snd.getsampwidth()==2
    SimTime.now=0.0;SimTime.audio_actions=[];SimTime.paints=[];SimTime.keys=[];SimTime.delivered=set()
    win=FakeWindow()
    ui=exp.UI(cfg,win)
    elapsed=ui.pictures(exp.get_images(emotion)[:4],6.0,emotion)
    starts=[a for a in SimTime.audio_actions if a[2]=='play']
    stops=[a for a in SimTime.audio_actions if a[2]=='stop']
    assert len(starts)==1,(emotion,starts)
    assert starts[0][1]==emotion
    assert len(stops)==2,(emotion,stops)
    assert abs((stops[-1][0]-starts[0][0])-24.0)<.2, (emotion,elapsed,starts,stops)
    assert 24.0<=elapsed<=24.1, (emotion,elapsed)
    assert not win.callbacks, 'flip callbacks must be empty'
    print('PASS:',emotion,'photos4×6s, audio24s, first flip playback, stop after images, elapsed',elapsed)
print('PASS: 三种图片与对应音频时长与同步逻辑已通过虚拟时钟测试')

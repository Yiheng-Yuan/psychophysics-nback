# -*- coding: utf-8 -*-
"""无PsychoPy依赖的完整实验流程/升级判定/CSV导出测试。"""
from pathlib import Path
import csv, json, random, shutil, tempfile
import run_experiment as exp
from nback_logic import generate_block, joint_level_decision, validate_config


def rows(path):
    with path.open('r',newline='',encoding='utf-8-sig') as f:
        return list(csv.DictReader(f))


class DummyUI:
    events=[]
    def __init__(self, cfg, existing_window=None): self.cfg=cfg
    def page(self, title, text, footer='按空格继续'): self.events.append(('page',title))
    def rest(self, seconds): self.events.append(('rest',seconds))
    def pictures(self, paths, duration, emotion):
        assert paths and len({x.parent.name for x in paths})==1
        assert emotion == paths[0].parent.name
        self.events.append(('images',paths[0].parent.name,len(paths)))
        return len(paths)*duration
    def close(self): pass


def simulate(level_cap, force_pass_6=False):
    cfg=exp.load_config()
    with tempfile.TemporaryDirectory() as td:
        root=Path(td)/'project'; root.mkdir()
        (root/'data').mkdir()
        shutil.copy2(exp.ROOT/'config.json',root/'config.json')
        shutil.copytree(exp.ROOT/'stimuli',root/'stimuli')
        old_root,old_ui,old_block=exp.ROOT,exp.UI,exp.run_block
        calls=[]
        def fake_block(ui,rng,paths,session_idx,emotion,distraction,n,rep,image_set):
            calls.append((emotion,n,distraction,rep))
            # 正常升级时仅无干扰22/24达标；有干扰19/24不达标。
            # 失败时两个条件分别18/24、16/24，都低于80%。
            passing=n<=level_cap[emotion]
            hits=8 if (passing or distraction=='without') else 7
            correct=(22 if distraction=='without' else 19) if passing else (18 if distraction=='without' else 16)
            return {'scored_trials':24, 'hits':hits,
                    'correct_rejections':correct-hits, 'accuracy':correct/24}
        try:
            exp.ROOT=root;exp.UI=DummyUI;exp.run_block=fake_block
            DummyUI.events=[]
            assert exp.run_experiment(participant_id='014') is True
            output=next((root/'data').iterdir())
            summary=rows(output/'summary.csv')
            levels=rows(output/'level_results.csv')
            conditions=rows(output/'condition_results.csv')
            image_rows=rows(output/'image_log.csv')
            stages=rows(output/'stage_log.csv')
            audio_rows=rows(output/'audio_log.csv')
            manifest=json.loads((output/'run_manifest.json').read_text(encoding='utf-8'))
            assert manifest['version']==exp.VERSION
            assert len(summary)==3 and len(conditions)==6
            assert [r['emotion'] for r in summary]==list(exp.build_schedule(exp.choose_emotion_order('014')))
            for r in summary:
                name=r['emotion']
                expect=level_cap[name]
                assert int(r['highest_either_n'])==expect,(name,r)
                assert int(r['last_tested_n'])==min(cfg['max_n'],expect+1)
            # emotion sequence is strictly contiguous; each emotion reaches its maximum before switching.
            trace=[x[0] for x in calls]
            order=list(exp.build_schedule(exp.choose_emotion_order('014')))
            assert list(dict.fromkeys(trace))==order
            for name in order:
                calls_for_emotion=[c for c in calls if c[0]==name]
                assert [x[1] for x in calls_for_emotion]==sorted(x[1] for x in calls_for_emotion)
                for n in range(1,min(6,level_cap[name]+1)+1):
                    assert len([x for x in calls_for_emotion if x[1]==n])==4
            # each tested N gets full 4-image induction of same emotion, before level start.
            assert len(image_rows)==4*len(levels)
            assert len(audio_rows)==len(levels)
            for ar in audio_rows:
                assert ar['audio_path']==f"stimuli/audio/{ar['emotion']}_24s.wav"
                assert float(ar['audio_duration_seconds'])==24.0
            for r in levels:
                e,n=r['emotion'],r['n']
                imgs=[x for x in image_rows if x['emotion']==e and x['n']==n]
                assert len(imgs)==4
                assert {x['stage'] for x in imgs}=={'full_induction'}
                assert all(x['image_path'].split('/')[1]==e for x in imgs)
                combined=float(r['combined_accuracy'])
                assert abs(combined-(float(r['without_accuracy'])+float(r['with_accuracy']))/2)<1e-8
                assert (r['level_pass']=='True')==(float(r['without_accuracy'])>=.8 or float(r['with_accuracy'])>=.8)
                assert (r['without_pass']=='True')==(float(r['without_accuracy'])>=.8)
                assert (r['with_pass']=='True')==(float(r['with_accuracy'])>=.8)
            for r in conditions:
                assert r['distractor_zh'] in ('有干扰','无干扰')
                e,n=r['emotion'],int(r['highest_either_n'])
                assert n==level_cap[e]
            assert len([x for x in stages if x['stage']=='induction_start'])==len(levels)
            assert len([x for x in stages if x['stage']=='emotion_complete'])==3
            assert len([x for x in stages if x['stage']=='block_ready_confirmed'])==4*len(levels)
            assert all(x['emotion']==image_rows[0]['emotion'] for x in image_rows[:4])
            return (len(levels),len(image_rows),len(calls))
        finally:
            exp.ROOT=old_root;exp.UI=old_ui;exp.run_block=old_block


def test_generator(cfg):
    for order_idx in range(6):
        seq=exp.build_schedule(order_idx)
        assert len(seq)==3 and len(set(seq))==3
    for n in range(1,7):
        for seed in range(150):
            seq=generate_block(n,24,8,random.Random(seed))
            assert len(seq)==24+n
            assert sum(1 for x in seq if x['scored'])==24
            assert sum(1 for x in seq if x['scored'] and x['is_match'])==8
            for i,t in enumerate(seq):
                if t['scored']:
                    assert t['is_match']==(t['word']==seq[i-n]['word'])
                    assert t['correct_key']==('j' if t['is_match'] else 'f')
                else: assert t['correct_key']==''
    def metrics(no_correct,with_correct):
        def two_blocks(correct):
            assert correct%2==0
            v=correct//2
            return [{'scored_trials':24,'hits':min(v,8),'correct_rejections':v-min(v,8)}]*2
        return joint_level_decision({'without':two_blocks(no_correct),'with':two_blocks(with_correct)},cfg)
    # 一种条件 >=80% 即通过，联合准确率即使 <80% 也可以升级。
    assert metrics(44,32)['level_pass']
    assert metrics(44,32)['combined_accuracy'] < .8
    assert metrics(32,44)['level_pass']
    assert not metrics(38,38)['level_pass']
    assert metrics(40,36)['level_pass']
    assert metrics(40,36)['without_pass'] and not metrics(40,36)['with_pass']


def main():
    cfg=exp.load_config();validate_config(cfg)
    assert cfg['max_n']==6 and cfg['upgrade_accuracy_threshold']==0.8
    assert cfg['feedback_seconds']==0.5
    assert cfg['max_n']==6 and cfg['trial_total_seconds']==2.0 and cfg['fixation_seconds']==0.2
    test_generator(cfg)
    for e in exp.EMOTIONS: assert len(exp.get_images(e))>=4
    normal=simulate({'positive':3,'neutral':2,'negative':1})
    ceiling=simulate({'positive':6,'neutral':6,'negative':6})
    print('PASS: 6种情绪顺序，1至6-back答案与刺激，任一条件80%判定，情绪不交错，逐级重播同类图片。')
    print('PASS: 正常路径(等级数/图片数/区块数)=',normal,'全部通过6-back=',ceiling)


if __name__=='__main__': main()

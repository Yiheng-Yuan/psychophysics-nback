# -*- coding: utf-8 -*-
"""可在普通Python运行的完整实验逻辑回归测试，不包含真实PsychoPy画面计时。"""
from __future__ import annotations
import csv
import json
import random
import shutil
import tempfile
from pathlib import Path

from nback_logic import generate_block, signal_detection_metrics, stable_pass, validate_config
import run_experiment as exp


def rows(p):
    with p.open('r', encoding='utf-8-sig', newline='') as f:
        return list(csv.DictReader(f))


class DummyUI:
    events = []
    def __init__(self, cfg, existing_window=None):
        self.cfg=cfg
    def page(self, title, description, *args):
        self.events.append(('page', title))
    def rest(self, seconds):
        self.events.append(('rest', seconds))
    def pictures(self, paths, duration):
        assert paths and all(p.exists() for p in paths)
        emotions={p.parent.name for p in paths}
        assert len(emotions)==1
        self.events.append(('images', tuple(emotions),len(paths)))
    def fixation(self, seconds):
        pass
    def word_trial(self, word, upper, lower, scored):
        self.events.append(('word',word,bool(upper)))
        return '', ''   # 故意不按键，1-back就停止，以检查停止时仍能写出数据
    def close(self):
        pass


def test_generator(cfg):
    for idx in range(6):
        schedule=exp.build_schedule(idx)
        assert len(schedule)==3 and set(schedule)==set(exp.EMOTIONS)
        for block in (1,2,3):
            for n in (1,2,3,4):
                assert set(exp.distraction_order(idx,block,n))=={'with','without'}
    for n in range(1,5):
        for seed in range(90):
            items=generate_block(n,24,8,random.Random(seed))
            assert len(items)==24+n
            assert sum(x['is_match'] for x in items)==8
            assert sum(x['scored'] for x in items)==24
            for k,x in enumerate(items):
                if k<n: assert not x['scored']
                else:
                    assert x['is_match']==(x['word']==items[k-n]['word'])
                    assert x['correct_key']==('j' if x['is_match'] else 'f')
            perfect=[{**t,'response_key':t['correct_key'],'correct':True,'rt':0.5}
                     for t in items if t['scored']]
            metric=signal_detection_metrics(perfect)
            assert metric['hits']==8 and metric['false_alarms']==0
            metric['response_rate']=1
            assert stable_pass([metric,metric],cfg)
            assert not stable_pass([metric],cfg)


def simulated_run(fake_root, run_block_patch=None):
    old_root,old_ui,old_block=exp.ROOT,exp.UI,exp.run_block
    try:
        exp.ROOT=fake_root
        exp.UI=DummyUI
        DummyUI.events=[]
        if run_block_patch:
            exp.run_block=run_block_patch
        ok=exp.run_experiment(participant_id='014')
        assert ok
        folders=list((fake_root/'data').iterdir())
        assert len(folders)==1,folders
        return folders[0],DummyUI.events[:]
    finally:
        exp.ROOT,exp.UI,exp.run_block=old_root,old_ui,old_block


def main():
    cfg=json.loads((exp.ROOT/'config.json').read_text(encoding='utf-8'))
    validate_config(cfg)
    assert 'mode' not in cfg
    assert 'practice_enabled' not in cfg
    assert cfg['word_visible_seconds']>=1.0
    test_generator(cfg)
    for emotion in exp.EMOTIONS:
        images=exp.get_images(emotion)
        assert len(images)>=4 and all(p.stat().st_size>1000 for p in images)

    with tempfile.TemporaryDirectory() as tmp:
        fake=Path(tmp)/'test-a'
        fake.mkdir();(fake/'data').mkdir()
        shutil.copy2(exp.ROOT/'config.json',fake/'config.json')
        shutil.copytree(exp.ROOT/'stimuli',fake/'stimuli')
        out,events=simulated_run(fake)
        s=rows(out/'summary.csv')
        sessions=rows(out/'sessions.csv')
        blocks=rows(out/'blocks.csv')
        images=rows(out/'image_log.csv')
        stage=rows(out/'stage_log.csv')
        trial=rows(out/'trials.csv')
        assert len(s)==3 and len(sessions)==6 and len(blocks)==12
        assert len(images)==12 and len({r['emotion'] for r in images})==3
        assert len(trial)==sum((24+1) for _ in range(12))
        assert all(r['n']=='1' for r in trial)
        assert all(int(r['highest_no_distractor_n'])==0 for r in s)
        assert all(int(r['highest_with_distractor_n'])==0 for r in s)
        assert [r['emotion'] for r in s]==list(exp.build_schedule(exp.choose_emotion_order('014')))
        assert len([r for r in stage if r['stage']=='induction_start'])==3
        assert len([r for r in stage if r['stage']=='emotion_complete'])==3
        # 某个情绪完成后，才允许下一个情绪开始（不得N1横跨三种情绪）。
        unique=[r['emotion'] for r in stage if r['stage']=='induction_start']
        for i,e in enumerate(unique):
            chunk=[r['emotion'] for r in stage if r['emotion']==e]
            assert chunk and len(set(chunk))==1
        order=[r['emotion'] for r in stage]
        first={e:order.index(e) for e in unique}
        last={e:len(order)-1-order[::-1].index(e) for e in unique}
        assert all(last[unique[i]]<first[unique[i+1]] for i in range(2))

    # 所有情绪的不同干扰条件给出不同通过等级，验证分条件停止、单情绪递进。
    with tempfile.TemporaryDirectory() as tmp:
        fake=Path(tmp)/'test-b';fake.mkdir();(fake/'data').mkdir()
        shutil.copy2(exp.ROOT/'config.json',fake/'config.json')
        shutil.copytree(exp.ROOT/'stimuli',fake/'stimuli')
        ceilings={
           'positive':{'without':4,'with':2},
           'neutral': {'without':2,'with':3},
           'negative':{'without':1,'with':1},
        }
        calls=[]
        def fake_block(ui,rng,paths,session_idx,emotion,distraction,n,rep,image_set):
            calls.append((emotion,n,distraction,rep))
            passed=n<=ceilings[emotion][distraction]
            return {'hit_rate':1.0 if passed else .0,
                    'false_alarm_rate':0.0 if passed else 1.0,
                    'response_rate':1.0,'dprime':2.5 if passed else 0}
        out,events=simulated_run(fake,fake_block)
        summaries={x['emotion']:x for x in rows(out/'summary.csv')}
        assert {e:(int(x['highest_no_distractor_n']),int(x['highest_with_distractor_n']))
                for e,x in summaries.items()} == {e:(v['without'],v['with']) for e,v in ceilings.items()}
        sessions=rows(out/'sessions.csv')
        for r in sessions:
            e,d=r['emotion'],r['distractor_level']
            attempted=[int(x) for x in r['completed_levels'].split(',')]
            expected=list(range(1,min(4,ceilings[e][d]+1)+1))
            assert attempted==expected,(r,attempted,expected)
        order=[x['emotion'] for x in rows(out/'stage_log.csv')]
        unique=list(exp.build_schedule(exp.choose_emotion_order('014')))
        prev_last=-1
        for e in unique:
            idx=[i for i,x in enumerate(order) if x==e]
            assert idx[0]>prev_last and idx==list(range(idx[0],idx[-1]+1))
            prev_last=idx[-1]
            ns=[n for ee,n,*_ in calls if ee==e]
            assert ns==sorted(ns),(e,ns)
        stages=rows(out/'stage_log.csv')
        assert len([x for x in stages if x['stage']=='induction_start'])==3
        assert len([x for x in stages if x['stage']=='booster_start'])==2
        assert len([x for x in stages if x['stage']=='emotion_complete'])==3
        assert all(x['emotion']==x['image_path'].split('/')[1] for x in rows(out/'image_log.csv'))

    print('PASS: 6套情绪顺序、N-back答案、自动升级与停止、单情绪内连续测试、Builder共用主程序数据记录。')


if __name__=='__main__':
    main()

# -*- coding: utf-8 -*-
"""情绪区块优先的词语 N-back：先一类情绪，再1-back逐级升到各条件上限。

PsychoPy Coder 或 Builder 共用此程序；不包含练习、情绪评分、注意探针或模式切换。
"""
from __future__ import annotations

import csv
import hashlib
import itertools
import json
import platform
import random
import re
import traceback
from datetime import datetime
from pathlib import Path

from nback_logic import (
    validate_config, generate_block, distractor_pair,
    signal_detection_metrics, stable_pass,
)

ROOT = Path(__file__).resolve().parent
EMOTIONS = ('positive', 'neutral', 'negative')

TRIAL_FIELDS = "participant order_index session emotion distractor_level n repetition trial_index scored word upper_distractor lower_distractor is_match is_lure correct_key response_key correct rt_seconds image_set timestamp".split()
BLOCK_FIELDS = "participant order_index session emotion distractor_level n repetition scored_trials n_targets n_nontargets hits misses false_alarms correct_rejections accuracy hit_rate false_alarm_rate balanced_accuracy dprime mean_correct_rt n_correct_rt response_rate block_pass".split()
SESSION_FIELDS = "participant order_index session emotion distractor_level highest_passed_n ceiling_at_max completed_levels stopped_after_failure timestamp".split()
SUMMARY_FIELDS = "participant order_index emotion emotion_block primary_highest_n highest_no_distractor_n highest_with_distractor_n loss_in_max_n both_completed".split()
IMAGE_FIELDS = "participant session emotion stage sequence image_path duration_seconds timestamp".split()
STAGE_FIELDS = "participant order_index emotion_block emotion stage n distractor timestamp".split()


class StopExperiment(Exception):
    """用户按ESC结束。"""


def load_config():
    with (ROOT / 'config.json').open('r', encoding='utf-8') as f:
        cfg = json.load(f)
    validate_config(cfg)
    return cfg


def save_csv_row(path, fields, row):
    path.parent.mkdir(parents=True, exist_ok=True)
    new_file = not path.exists() or path.stat().st_size == 0
    with path.open('a', newline='', encoding='utf-8-sig') as f:
        writer = csv.DictWriter(f, fieldnames=fields, extrasaction='ignore')
        if new_file:
            writer.writeheader()
        writer.writerow({k: row.get(k, '') for k in fields})
        f.flush()


def choose_emotion_order(pid):
    """若被试编号以数字结尾，顺序按编号 mod 6；其余由稳定哈希分配。"""
    m = re.search(r'(\d+)$', pid)
    if m:
        return int(m.group(1)) % 6
    return int.from_bytes(hashlib.sha256(pid.encode('utf-8')).digest()[:4], 'big') % 6


def build_schedule(order_index):
    """返回三种情绪的完整区块顺序；每种情绪只出现一次。"""
    return list(itertools.permutations(EMOTIONS))[order_index]


def distraction_order(order_index, emotion_block, n):
    """在每个N等级下平衡先测有/无干扰，且不跨情绪切换。"""
    if (order_index + emotion_block + n) % 2:
        return ('without', 'with')
    return ('with', 'without')


def stage_row(paths, emotion_block, emotion, stage, n='', distractor=''):
    save_csv_row(paths['stage_log'], STAGE_FIELDS, {
        'participant':paths['participant'], 'order_index':paths['order_index'],
        'emotion_block':emotion_block, 'emotion':emotion, 'stage':stage,
        'n':n, 'distractor':distractor,
        'timestamp':datetime.now().isoformat(timespec='seconds'),
    })


def get_images(emotion):
    found = sorted((ROOT/'stimuli'/emotion).glob('*.jpg'))
    if len(found) < 4:
        raise FileNotFoundError(f'{emotion} 类别中至少需要4张jpg图片。')
    return found


class UI:
    def __init__(self, cfg, existing_window=None):
        from psychopy import visual, core, event
        self.visual, self.core, self.event = visual, core, event
        self.cfg = cfg
        self.owns_window = existing_window is None
        self.font = cfg.get('font_override') or {
            'Windows': 'Microsoft YaHei', 'Darwin': 'PingFang SC',
            'Linux': 'Noto Sans CJK SC',
        }.get(platform.system(), 'Arial Unicode MS')
        self.win = existing_window or visual.Window(
            size=(cfg['window_width'],cfg['window_height']),
            fullscr=bool(cfg['fullscreen']), units='height',
            color=(-.83,-.85,-.89), allowGUI=True, waitBlanking=True,
        )
        self.head = visual.TextStim(self.win, text='', font=self.font, pos=(0,.29),
                                    height=.053, color='#F0F3F9', bold=True, wrapWidth=1.4)
        self.body = visual.TextStim(self.win, text='', font=self.font, pos=(0,.02),
                                    height=.039, color='#E6ECF4', wrapWidth=1.4, alignText='center')
        self.foot = visual.TextStim(self.win, text='', font=self.font, pos=(0,-.35),
                                    height=.025, color='#AFBCD0', wrapWidth=1.45)
        self.center = visual.TextStim(self.win, text='', font=self.font, pos=(0,0),
                                      height=.091, bold=True, color='#FAFBFF')
        self.upper = visual.TextStim(self.win, text='', font=self.font, pos=(0,.20),
                                     height=.052, color='#B6C1D0')
        self.lower = visual.TextStim(self.win, text='', font=self.font, pos=(0,-.20),
                                     height=.052, color='#B6C1D0')
        self.fix = visual.TextStim(self.win, text='+', font=self.font, pos=(0,0),
                                   height=.070, color='#BDC9DB')
        self.photo = visual.ImageStim(self.win, image=str(get_images('neutral')[0]), pos=(0,0), size=(1.44,.81),
                                      units='height', interpolate=True)

    def check_escape(self):
        if self.event.getKeys(keyList=['escape']):
            raise StopExperiment('ESC')

    def page(self, title, text, footer='按空格继续'):
        self.event.clearEvents(eventType='keyboard')
        self.head.text, self.body.text, self.foot.text = title, text, footer
        while True:
            self.head.draw(); self.body.draw(); self.foot.draw()
            self.win.flip()
            keys = self.event.getKeys(keyList=['space','escape'])
            if 'escape' in keys:
                raise StopExperiment('ESC')
            if 'space' in keys:
                return

    def rest(self, seconds):
        if seconds <= 0: return
        clock = self.core.Clock()
        while clock.getTime() < seconds:
            self.head.text = '请稍作休息'
            self.body.text = '下一组任务即将开始'
            self.foot.text = ''
            self.head.draw(); self.body.draw(); self.win.flip()
            self.check_escape()

    def pictures(self, paths, duration):
        """连续放映图片；最后一张结束后不插入确认页或评分页。"""
        self.event.clearEvents(eventType='keyboard')
        for path in paths:
            self.photo.image = str(path)
            clock = self.core.Clock()
            first = True
            while first or clock.getTime() < duration:
                self.photo.draw()
                self.win.flip()
                if first:
                    clock.reset()
                    first = False
                self.check_escape()

    def fixation(self, seconds):
        clock = self.core.Clock()
        self.event.clearEvents(eventType='keyboard')
        while clock.getTime() < seconds:
            self.fix.draw(); self.win.flip(); self.check_escape()

    def word_trial(self, word, upper, lower, scored):
        """中央词及干扰词1.05s，再用注视点补足总2.25s；反应时从首帧显示起计。"""
        visible_sec = float(self.cfg['word_visible_seconds'])
        total_sec = float(self.cfg['trial_total_seconds'])
        self.event.clearEvents(eventType='keyboard')
        clock = self.core.Clock()
        first = True
        response, rt = '', ''
        while first or clock.getTime() < total_sec:
            elapsed = clock.getTime()
            if first or elapsed < visible_sec:
                self.center.text = word
                self.center.draw()
                if upper:
                    self.upper.text, self.lower.text = upper, lower
                    self.upper.draw(); self.lower.draw()
            else:
                self.fix.draw()
            self.win.flip()
            if first:
                clock.reset()
                first = False
            for key, timestamp in self.event.getKeys(keyList=['f','j','escape'],timeStamped=clock):
                if key == 'escape':
                    raise StopExperiment('ESC')
                if scored and not response:
                    response, rt = key, round(float(timestamp),4)
        return response,rt

    def close(self):
        if self.owns_window:
            self.win.close()
            self.core.quit()


def participant_prompt():
    from psychopy import gui
    form={'被试编号':'001'}
    dialog=gui.DlgFromDict(dictionary=form, title='词语 N-back 实验', order=['被试编号'])
    if not dialog.OK: return None
    return form['被试编号']


def normalized_pid(raw):
    pid=re.sub(r'[^A-Za-z0-9_-]', '_', str(raw).strip())[:40]
    if not pid: raise ValueError('被试编号不能为空')
    return pid


def record_images(ui, rng, paths, emotion, session_idx, stage='initial', count=None, duration=None):
    cfg=ui.cfg
    count = int(count if count is not None else cfg['emotion_images_per_induction'])
    duration = float(duration if duration is not None else cfg['emotion_image_seconds'])
    images=get_images(emotion)
    # 不重复取样并随机排序；同情绪池中的相似构图仅作为课程实验用示例刺激。
    chosen=rng.sample(images, k=min(count,len(images)))
    for i,p in enumerate(chosen,1):
        save_csv_row(paths['image_log'],IMAGE_FIELDS,{
            'participant':paths['participant'], 'session':session_idx,'emotion':emotion,
            'stage':stage,'sequence':i,'image_path':str(p.relative_to(ROOT)),
            'duration_seconds':duration,'timestamp':datetime.now().isoformat(timespec='seconds')})
    ui.pictures(chosen,duration)
    return ','.join(p.name for p in chosen)


def run_block(ui,rng,paths,session_idx,emotion,distraction,n,rep,image_set):
    cfg=ui.cfg
    ts=generate_block(n,int(cfg['block_scored_trials']),int(cfg['matches_per_block']),rng)
    logged=[]
    for t in ts:
        ui.fixation(float(cfg['fixation_seconds']))
        upper,lower=distractor_pair(t['word'],rng) if distraction=='with' else ('','')
        response,rt=ui.word_trial(t['word'],upper,lower,t['scored'])
        correct=(response==t['correct_key']) if t['scored'] else ''
        if t['scored']:
            logged.append({**t,'response_key':response,'correct':correct,'rt':rt})
        save_csv_row(paths['trials'],TRIAL_FIELDS,{
            'participant':paths['participant'],'order_index':paths['order_index'],
            'session':session_idx,'emotion':emotion,'distractor_level':distraction,
            'n':n,'repetition':rep,'trial_index':t['trial_index'],
            'scored':t['scored'],'word':t['word'],
            'upper_distractor':upper,'lower_distractor':lower,
            'is_match':t['is_match'] if t['scored'] else '',
            'is_lure':t['is_lure'] if t['scored'] else '',
            'correct_key':t['correct_key'],'response_key':response,
            'correct':correct,'rt_seconds':rt,'image_set':image_set,
            'timestamp':datetime.now().isoformat(timespec='seconds'),
        })
    m=signal_detection_metrics(logged)
    m['response_rate']=sum(bool(x['response_key']) for x in logged)/len(logged)
    meets=(m['hit_rate']>=cfg['minimum_hit_rate'] and
           m['false_alarm_rate']<=cfg['maximum_false_alarm_rate'] and
           m['response_rate']>=cfg['minimum_response_rate'] and
           m['dprime']>=cfg['minimum_dprime'])
    save_csv_row(paths['blocks'],BLOCK_FIELDS,{
        'participant':paths['participant'],'order_index':paths['order_index'],
        'session':session_idx,'emotion':emotion,'distractor_level':distraction,
        'n':n,'repetition':rep, **m, 'block_pass':meets,
    })
    return m


def block_description(n, emotion_block):
    return (f'词语任务 · 第 {emotion_block}/3 段 · {n}-back',
            f'判断中央单词是否与前面第 {n} 个单词相同：相同按 J，不同按 F。\n'
            '如果上下方出现其他单词，请忽略，只看中央单词。\n'
            f'每个区块的前 {n} 个单词用于准备，不用按键。')


def run_emotion_ladder(ui,rng,paths,emotion_block,emotion):
    """情绪>等级>干扰>重复区块。每个情绪只做一次初始图片诱导。"""
    cfg=ui.cfg
    highest={'without':0,'with':0}
    attempted={'without':[],'with':[]}
    active={'without','with'}
    # 第一张图片之前显示完整任务说明，图片结束后直接进入1-back。
    title,description=block_description(1,emotion_block)
    ui.page(title,description)
    stage_row(paths,emotion_block,emotion,'induction_start')
    image_set=record_images(ui,rng,paths,emotion,emotion_block,'initial')
    stage_row(paths,emotion_block,emotion,'induction_end')
    for n in range(1,int(cfg['max_n'])+1):
        if not active:
            break
        if n>1:
            ui.rest(float(cfg['between_level_rest_seconds']))
            title,description=block_description(n,emotion_block)
            ui.page(title,description)
            # 仅补充同一种情绪图片，不穿插其他情绪；显示后直接开始试次。
            if n==3 and int(cfg.get('booster_images_per_induction',0))>0:
                stage_row(paths,emotion_block,emotion,'booster_start',n)
                image_set=record_images(ui,rng,paths,emotion,emotion_block,'booster',
                    cfg['booster_images_per_induction'],cfg['booster_image_seconds'])
                stage_row(paths,emotion_block,emotion,'booster_end',n)
        stage_row(paths,emotion_block,emotion,'level_start',n)
        for distraction in distraction_order(paths['order_index'],emotion_block,n):
            if distraction not in active:
                continue
            blocks=[]
            stage_row(paths,emotion_block,emotion,'condition_start',n,distraction)
            for rep in range(1,int(cfg['repeat_blocks'])+1):
                if rep>1:
                    ui.rest(float(cfg['between_block_rest_seconds']))
                blocks.append(run_block(ui,rng,paths,emotion_block,emotion,
                                        distraction,n,rep,image_set))
            attempted[distraction].append(n)
            if stable_pass(blocks,cfg):
                highest[distraction]=n
                stage_row(paths,emotion_block,emotion,'level_pass',n,distraction)
            else:
                active.remove(distraction)
                stage_row(paths,emotion_block,emotion,'level_fail',n,distraction)
        stage_row(paths,emotion_block,emotion,'level_end',n)
    for distraction in ('without','with'):
        ceiling=highest[distraction]==int(cfg['max_n'])
        save_csv_row(paths['sessions'],SESSION_FIELDS,{
            'participant':paths['participant'],'order_index':paths['order_index'],
            'session':emotion_block,'emotion':emotion,'distractor_level':distraction,
            'highest_passed_n':highest[distraction],'ceiling_at_max':ceiling,
            'completed_levels':','.join(map(str,attempted[distraction])),
            'stopped_after_failure':not ceiling,
            'timestamp':datetime.now().isoformat(timespec='seconds'),
        })
    stage_row(paths,emotion_block,emotion,'emotion_complete')
    return highest


def run_experiment(participant_id=None, existing_window=None, show_intro=True, show_end=True):
    cfg=load_config()
    if participant_id is None:
        participant_id=participant_prompt()
        if participant_id is None: return False
    pid=normalized_pid(participant_id)
    order_index=choose_emotion_order(pid)
    stamp=datetime.now().strftime('%Y%m%d_%H%M%S_%f')
    rng_seed=int.from_bytes(hashlib.sha256(f'{pid}:{stamp}'.encode('utf-8')).digest()[:8],'big')
    rng=random.Random(rng_seed)
    out=ROOT/'data'/f'{pid}_{stamp}'
    out.mkdir(parents=True,exist_ok=True)
    paths={'participant':pid,'order_index':order_index}
    for name in ('trials','blocks','sessions','summary','image_log','stage_log'):
        paths[name]=out/f'{name}.csv'
    with (out/'run_manifest.json').open('w',encoding='utf-8') as f:
        json.dump({'participant':pid,'order_index':order_index,'seed':rng_seed,
                   'configuration':cfg,'stimuli_are_normed':False,
                   'order_rule':'emotion > n > distractor > two repeated blocks',
                   'emotion_order':list(build_schedule(order_index)),
                   'start_time':datetime.now().isoformat(timespec='seconds')},
                  f,ensure_ascii=False,indent=2)
    ui=None
    try:
        ui=UI(cfg,existing_window)
        if show_intro:
            ui.page('词语 N-back 任务',
                    '屏幕会连续出现单词，只判断中央目标词。\n'
                    '当前词与前面第N个词相同，按 J；不同，按 F。\n'
                    '若出现上下方无关单词，请忽略。\n'
                    '每组的前N个词不需要作答，随后所有词尽量准确、及时作答。')
        scores={}
        schedule=build_schedule(order_index)
        for emotion_block,emotion in enumerate(schedule,1):
            if emotion_block>1:
                ui.rest(float(cfg['between_emotion_rest_seconds']))
            # 本情绪从1-back测起，直到两种干扰条件各自停止升级，再切换情绪。
            scores[emotion]=run_emotion_ladder(ui,rng,paths,emotion_block,emotion)
            save_csv_row(paths['summary'],SUMMARY_FIELDS,{
                'participant':pid,'order_index':order_index,'emotion':emotion,
                'emotion_block':emotion_block,
                'primary_highest_n':scores[emotion]['without'],
                'highest_no_distractor_n':scores[emotion]['without'],
                'highest_with_distractor_n':scores[emotion]['with'],
                'loss_in_max_n':scores[emotion]['without']-scores[emotion]['with'],
                'both_completed':True,
            })
        if show_end:
            ui.page('实验完成','本次词语判断任务已结束。感谢参与。','按空格结束')
        return True
    except StopExperiment as e:
        (out/'stopped.txt').write_text(str(e),encoding='utf-8')
        return False
    except Exception:
        err=traceback.format_exc()
        (out/'error_traceback.txt').write_text(err,encoding='utf-8')
        print(err)
        raise
    finally:
        if ui is not None:
            ui.close()


if __name__=='__main__':
    run_experiment()

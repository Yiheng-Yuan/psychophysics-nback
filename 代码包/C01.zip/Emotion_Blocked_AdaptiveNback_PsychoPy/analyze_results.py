# -*- coding: utf-8 -*-
"""汇总完成实验的最高稳定 N-back 等级，不计算未收集的主观情绪/注意分数。"""
from __future__ import annotations
import csv
import statistics
from collections import defaultdict
from pathlib import Path

ROOT=Path(__file__).resolve().parent
DATA=ROOT/'data'


def load_rows(path):
    with path.open('r',newline='',encoding='utf-8-sig') as f:
        return list(csv.DictReader(f))


def write_rows(path,fields,rows):
    with path.open('w',newline='',encoding='utf-8-sig') as f:
        w=csv.DictWriter(f,fieldnames=fields)
        w.writeheader();w.writerows(rows)


def main():
    groups=defaultdict(list)
    matched=defaultdict(dict)
    total=0
    for folder in sorted(DATA.iterdir()):
        if not folder.is_dir() or not (folder/'summary.csv').exists():
            continue
        try:
            rows=load_rows(folder/'summary.csv')
            if len(rows)!=3 or {r['emotion'] for r in rows}!={'positive','neutral','negative'}:
                continue
            if any(r['both_completed'].lower() not in ('true','1') for r in rows):
                continue
            total+=1
            for r in rows:
                e=r['emotion']
                n0=int(r['highest_no_distractor_n']);n1=int(r['highest_with_distractor_n'])
                groups[(e,'without')].append(n0)
                groups[(e,'with')].append(n1)
                matched[folder.name][e]=(n0,n1)
        except (ValueError,KeyError,OSError):
            continue
    if not total:
        print('未发现已完成的实验。请先运行 PsychoPy 并完成全部3个情绪阶段（其中包含6个干扰子条件）。')
        return
    output=[]
    names={'positive':'积极','neutral':'中性','negative':'消极'}
    for e in ('positive','neutral','negative'):
        for d in ('without','with'):
            ns=groups[(e,d)]
            output.append(dict(emotion=e,emotion_zh=names[e],distractor=d,
                               n=len(ns),mean_highest_n=round(statistics.mean(ns),3),
                               median_highest_n=statistics.median(ns),
                               sd_highest_n=round(statistics.stdev(ns),3) if len(ns)>1 else ''))
    write_rows(DATA/'group_summary_descriptive.csv',
               ['emotion','emotion_zh','distractor','n','mean_highest_n',
                'median_highest_n','sd_highest_n'],output)
    paired=[]
    for key,s in matched.items():
        for e, vals in s.items():
            paired.append(dict(session=key,emotion=e,no_distractor=vals[0],
                               with_distractor=vals[1],difference=vals[0]-vals[1]))
    write_rows(DATA/'paired_differences.csv',
               ['session','emotion','no_distractor','with_distractor','difference'],paired)
    print(f'完成数据：{total}次；输出 data/group_summary_descriptive.csv、data/paired_differences.csv')


if __name__=='__main__':main()

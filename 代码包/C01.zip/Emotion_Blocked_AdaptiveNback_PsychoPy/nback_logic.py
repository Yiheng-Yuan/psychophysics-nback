# -*- coding: utf-8 -*-
"""词语 N-back 随机生成、计分和等级判定（无 PsychoPy 依赖）。"""
from __future__ import annotations
import random
from statistics import NormalDist

WORDS = """苹果 书包 桌子 椅子 窗户 门口 河流 山谷 森林 草地 石头 纸张 铅笔 钢笔 橡皮 书本 地图 信封 钥匙 水杯 茶壶 碗筷 毛巾 牙刷 梳子 镜子 衣柜 衬衫 裤子 鞋子 袜子 手套 帽子 雨伞 皮箱 背包 电灯 台灯 电池 钟表 相机 电话 电脑 鼠标 键盘 屏幕 音箱 耳机 电线 书架 抽屉 地板 墙壁 屋顶 厨房 客厅 走廊 楼梯 电梯 公园 花园 树叶 花朵 树枝 花盆 湖泊 小溪 岛屿 海岸 沙滩 田野 小路 桥梁 马路 车站 火车 汽车 轮船 飞机 车轮 车票 纸箱 木箱 木板 铁门 玻璃 瓷砖 窗帘 被子 枕头 床单 地毯 篮子 盒子 瓶子 罐子 勺子 叉子 盘子 菜篮 稻谷 玉米 土豆 黄瓜 萝卜 竹子 橘子 香蕉 葡萄 梨子 桃子 西瓜""".split()


def validate_config(cfg: dict) -> None:
    required = ["max_n", "block_scored_trials", "matches_per_block", "repeat_blocks",
                "word_visible_seconds", "trial_total_seconds", "fixation_seconds",
                "emotion_image_seconds", "emotion_images_per_induction"]
    for k in required:
        if k not in cfg:
            raise ValueError("配置文件缺少: " + k)
    if not 1 <= int(cfg["max_n"]) <= 8:
        raise ValueError("max_n 应为1至8")
    n = int(cfg["block_scored_trials"]); k = int(cfg["matches_per_block"])
    if n < 10 or not (3 <= k < n):
        raise ValueError("试次数量或匹配数设置不合理")
    if int(cfg["repeat_blocks"]) != 2:
        raise ValueError("稳定通过判定固定要求每级重复两个区块")
    if not 0 < cfg["word_visible_seconds"] < cfg["trial_total_seconds"]:
        raise ValueError("单词显示时长应小于整个试次时长")
    if cfg["emotion_image_seconds"] <= 0 or cfg["emotion_images_per_induction"] < 1:
        raise ValueError("情绪图片诱导的时间或数量无效")
    for key in ("booster_image_seconds", "between_emotion_rest_seconds", "between_level_rest_seconds", "between_block_rest_seconds"):
        if float(cfg[key]) < 0:
            raise ValueError(key + "不能为负数")
    if int(cfg["booster_images_per_induction"]) < 0:
        raise ValueError("补充情绪图片数量不能为负数")

def generate_block(n: int, scored_trials: int, matches: int, rng: random.Random, words=None):
    """Generate n unscored warmup items followed by scored N-back items.

    Nonmatches can include occasional n±1 lures. All intended labels are
    verified against the actual lag-n word sequence prior to returning.
    """
    pool = list(words if words is not None else WORDS)
    if len(set(pool)) < 30:
        raise ValueError("词库过小")
    if not 1 <= n <= 8:
        raise ValueError("N 必须在1到8之间")
    if not (0 < matches < scored_trials):
        raise ValueError("匹配试次数不正确")
    targets = [True] * matches + [False] * (scored_trials - matches)
    rng.shuffle(targets)
    sequence = []
    result = []
    for i in range(n + scored_trials):
        scored = (i >= n)
        should_match = targets[i-n] if scored else False
        is_lure = False
        if should_match:
            word = sequence[i - n]
        else:
            lag_word = sequence[i-n] if scored else None
            # Use controlled nearby-lag lure on approximately 20% of nontargets.
            candidates = []
            for lag in (n+1, n-1):
                if lag >= 1 and i >= lag:
                    w = sequence[i-lag]
                    if w != lag_word and w not in candidates:
                        candidates.append(w)
            if scored and candidates and rng.random() < 0.20:
                word = rng.choice(candidates)
                is_lure = True
            else:
                forbidden = set(sequence[max(0, i-3):i])
                if lag_word:
                    forbidden.add(lag_word)
                choices = [w for w in pool if w not in forbidden]
                word = rng.choice(choices)
        sequence.append(word)
        actual = scored and (word == sequence[i-n])
        assert (not scored) or actual == should_match
        result.append({
            "trial_index": i+1,
            "scored": scored,
            "word": word,
            "is_match": actual,
            "is_lure": is_lure,
            "correct_key": ("j" if actual else "f") if scored else "",
        })
    assert sum(t["is_match"] for t in result if t["scored"]) == matches
    assert sum(bool(t["scored"]) for t in result) == scored_trials
    return result


def distractor_pair(target_word: str, rng: random.Random, words=None):
    pool = list(words if words is not None else WORDS)
    pair = rng.sample([w for w in pool if w != target_word], 2)
    return pair[0], pair[1]


def signal_detection_metrics(trials):
    """Scored-trial metrics with log-linear correction for d-prime."""
    rows = [x for x in trials if x.get("scored", True)]
    targets = [x for x in rows if x["is_match"]]
    non_targets = [x for x in rows if not x["is_match"]]
    hit = sum(x.get("response_key") == "j" for x in targets)
    false_alarm = sum(x.get("response_key") == "j" for x in non_targets)
    miss = sum(x.get("response_key") != "j" for x in targets)
    correct_reject = sum(x.get("response_key") == "f" for x in non_targets)
    total = len(rows)
    correct = hit + correct_reject
    hit_rate = hit / len(targets) if targets else float("nan")
    fa_rate = false_alarm / len(non_targets) if non_targets else float("nan")
    balanced_acc = (hit_rate + 1 - fa_rate) / 2 if targets and non_targets else float("nan")
    if targets and non_targets:
        adj_hit = (hit + .5) / (len(targets) + 1)
        adj_fa = (false_alarm + .5) / (len(non_targets) + 1)
        z = NormalDist().inv_cdf
        dprime = z(adj_hit) - z(adj_fa)
    else:
        dprime = float("nan")
    rts = [float(x["rt"]) for x in rows if x.get("correct") and x.get("rt") not in (None, "")]
    return dict(scored_trials=total, n_targets=len(targets), n_nontargets=len(non_targets),
                hits=hit, misses=miss, false_alarms=false_alarm, correct_rejections=correct_reject,
                accuracy=correct / total if total else float("nan"), hit_rate=hit_rate,
                false_alarm_rate=fa_rate, balanced_accuracy=balanced_acc, dprime=dprime,
                mean_correct_rt=sum(rts)/len(rts) if rts else float("nan"),
                n_correct_rt=len(rts))


def stable_pass(block_metrics: list, criteria: dict) -> bool:
    """Both subblocks must show acceptable basic performance, aggregate d' must pass.

    A no-response is treated as miss for targets AND as incorrect on non-targets
    by the task correctness column; here no-responses must separately be limited.
    """
    if len(block_metrics) != int(criteria["repeat_blocks"]):
        return False
    if any(b["hit_rate"] < criteria["minimum_hit_rate"] for b in block_metrics):
        return False
    if any(b["false_alarm_rate"] > criteria["maximum_false_alarm_rate"] for b in block_metrics):
        return False
    if any(b["response_rate"] < criteria["minimum_response_rate"] for b in block_metrics):
        return False
    return all(b["dprime"] >= criteria["minimum_dprime"] for b in block_metrics)

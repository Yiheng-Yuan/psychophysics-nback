# -*- coding: utf-8 -*-
"""独立的 1–3-back 热身，复用正式实验的试次界面与时序。"""

from run_experiment import StopExperiment, UI, load_config

PRACTICE_WORDS = {
    1: '铅笔 铅笔 帽子 苹果 苹果 台灯 钥匙 钥匙 书包',
    2: '帽子 台灯 苹果 台灯 纸箱 台灯 钥匙 书包 毛巾 书包',
    3: '纸箱 钥匙 苹果 纸箱 帽子 毛巾 钥匙 帽子 台灯 书包 帽子',
}


def practice_trials(n):
    words = PRACTICE_WORDS[n].split()
    return [
        (word, '' if i < n else 'j' if word == words[i - n] else 'f')
        for i, word in enumerate(words)
    ]


def run_warmup(ui):
    for n in PRACTICE_WORDS:
        ui.page(
            f'{n}-back 热身',
            f'当前词和往前第 {n} 个词相同，按 J。不同，按 F。\n\n'
            f'每个词都会进入序列，无论你按了哪个键。\n'
            f'前 {n} 个词只需记住，等后面的词出现再开始作答。',
            '按空格开始 · 按 Esc 退出',
        )
        correct = 0
        for word, key in practice_trials(n):
            ui.fixation(float(ui.cfg['fixation_seconds']))
            response, _ = ui.word_trial(word, '', '', bool(key), key)
            correct += bool(key) and response == key
        ui.page(
            f'{n}-back 练习结果',
            f'答对 {correct} / 8 题',
            '按空格继续 · 按 Esc 退出',
        )
    ui.page('热身完成', '可以开始正式实验了。', '按空格退出')


if __name__ == '__main__':
    ui = UI(load_config())
    try:
        run_warmup(ui)
    except StopExperiment:
        pass
    finally:
        ui.close()

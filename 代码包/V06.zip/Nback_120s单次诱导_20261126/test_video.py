"""Mock media/clock test; no decoder, real display or audio hardware is used."""
from pathlib import Path
from tempfile import TemporaryDirectory
from types import SimpleNamespace
import warnings
from unittest.mock import patch
import run_experiment as e
from test_feedback import SimTime, FakeClock, FakeWindow

class Movie:
    def __init__(self, duration):
        self.duration=duration; self.frameSize=(1920,1080); self.stopped=False
        self.origin=None; self.size=None
    def play(self): self.origin=SimTime.now
    @property
    def isFinished(self): return self.origin is not None and SimTime.now-self.origin>=self.duration
    def draw(self): pass
    def stop(self): self.stopped=True


class FrameErrorMovie(Movie):
    def __init__(self, duration, failure_time, last_pts):
        super().__init__(duration)
        self.failure_time = failure_time
        self.pts = last_pts

    def draw(self):
        if SimTime.now - self.origin >= self.failure_time:
            raise RuntimeError('Failed to return a frame after multiple attempts.')

def main():
    cfg=e.load_config()
    p,d='initial',120
    assert e.validate_video_duration(cfg,p,d)==d
    for bad in (d-20,d+20,float('nan')):
        try: e.validate_video_duration(cfg,p,bad)
        except ValueError: pass
        else: raise AssertionError('invalid duration accepted')
    SimTime.now=0
    ui=e.UI.__new__(e.UI);ui.cfg=cfg;ui.win=FakeWindow();ui.win.size=(1280,800)
    ui.core=SimpleNamespace(Clock=FakeClock); ui.event=SimpleNamespace(clearEvents=lambda **kw:None)
    ui.check_escape=lambda:None
    m=Movie(d);ui.open_movie=lambda path:m
    dur,elapsed=ui.play_video(Path('mock.mp4'),p)
    assert dur==d and d<=elapsed<=d+.05 and m.stopped and ui.current_movie is None
    assert abs(m.size[0]/m.size[1]-1920/1080)<1e-9
    # abort must stop the audio/video player and clear current reference
    m=Movie(d);ui.open_movie=lambda path:m
    def abort(): raise e.StopExperiment('ESC')
    ui.check_escape=abort
    try: ui.play_video(Path('mock.mp4'),p)
    except e.StopExperiment: pass
    else: raise AssertionError('ESC ignored')
    assert m.stopped and ui.current_movie is None
    ui.check_escape = lambda: None
    def wait(seconds):
        SimTime.now += max(seconds, 0.000001)
    ui.core.wait = wait
    m = FrameErrorMovie(d, d - 0.15, d - 0.20)
    ui.open_movie = lambda path: m
    with warnings.catch_warnings(record=True) as caught:
        duration, elapsed = ui.play_video(Path('tail.mp4'), p)
    assert len(caught) == 1 and duration == d and d <= elapsed <= d + 0.05
    assert m.stopped and ui.current_movie is None

    for failure_time, last_pts in ((d - 2, d - 2.1), (d - 0.15, d - 2)):
        m = FrameErrorMovie(d, failure_time, last_pts)
        ui.open_movie = lambda path: m
        try:
            ui.play_video(Path('interrupted.mp4'), p)
        except RuntimeError as error:
            assert str(error) == 'Failed to return a frame after multiple attempts.'
        else:
            raise AssertionError('interrupted playback accepted')
        assert m.stopped and ui.current_movie is None
    with TemporaryDirectory() as td, patch.object(e,'ROOT',Path(td)):
        try: e.check_video_files(cfg)
        except FileNotFoundError: pass
        else: raise AssertionError('missing clips accepted')
        for emotion in e.EMOTIONS:
            path=e.video_path(emotion,'initial');path.parent.mkdir(parents=True,exist_ok=True)
            path.write_bytes(emotion.encode())
        assert len(e.check_video_files(cfg))==3
    print('PASS video duration, aspect ratio, full playback loop, ESC cleanup end-of-file handling, interrupted playback rejection and missing media preflight (mocks only)')
if __name__=='__main__':main()

# -*- coding: utf-8 -*-
"""从当前版本trials.csv汇总各被试、情绪、N、干扰条件的诱饵行为。"""
import csv
from collections import defaultdict
from pathlib import Path

ROOT=Path(__file__).resolve().parent
DATA=ROOT/'data'
FIELDS=['session','participant','emotion','emotion_zh','n','distractor_level','distractor_zh',
        'n_scored','match_n','lure_n','other_n','overall_accuracy',
        'match_hit_rate','lure_correct_rate','lure_false_alarm_rate',
        'lure_omission_rate','other_correct_rate','response_rate',
        'familiarity_rule_accuracy','all_f_rule_accuracy']

def mean_bool(rows,cb):
    return round(sum(bool(cb(r)) for r in rows)/len(rows),5) if rows else ''

def main():
    DATA.mkdir(exist_ok=True)
    results=[]
    for folder in sorted(DATA.iterdir()):
        path=folder/'trials.csv'
        manifest=folder/'run_manifest.json'
        if not path.exists() or not manifest.exists():
            continue
        import json
        info=json.loads(manifest.read_text(encoding='utf-8'))
        if '10words_8-8-8_rt3_fix07' not in info.get('version',''):
            continue
        with path.open(newline='',encoding='utf-8-sig') as f:
            rows=[r for r in csv.DictReader(f) if r['scored']=='True']
        groups=defaultdict(list)
        for r in rows:
            groups[(r['participant'],r['emotion'],r['n'],r['distractor_level'])].append(r)
        for (pid,emotion,n,distractor),group in groups.items():
            matches=[r for r in group if r['trial_type']=='match']
            lures=[r for r in group if r['trial_type']=='lure']
            others=[r for r in group if r['trial_type']=='other_nonmatch']
            if len(group)%24 or len(matches)*3!=len(group) or len(lures)*3!=len(group) or len(others)*3!=len(group):
                print('警告：区块不完整或试次配额异常：',folder.name,emotion,n,distractor)
            results.append(dict(session=folder.name,participant=pid,emotion=emotion,
                emotion_zh=group[0].get('emotion_zh',''),n=n,distractor_level=distractor,
                distractor_zh=group[0].get('distractor_zh',''),n_scored=len(group),
                match_n=len(matches),lure_n=len(lures),other_n=len(others),
                overall_accuracy=mean_bool(group,lambda r:r['correct']=='True'),
                match_hit_rate=mean_bool(matches,lambda r:r['response_key']=='j'),
                lure_correct_rate=mean_bool(lures,lambda r:r['response_key']=='f'),
                lure_false_alarm_rate=mean_bool(lures,lambda r:r['response_key']=='j'),
                lure_omission_rate=mean_bool(lures,lambda r:r['response_key']==''),
                other_correct_rate=mean_bool(others,lambda r:r['response_key']=='f'),
                response_rate=mean_bool(group,lambda r:r['response_key'] in ('f','j')),
                familiarity_rule_accuracy=mean_bool(group,lambda r:('j' if r['seen_before']=='True' else 'f')==r['correct_key']),
                all_f_rule_accuracy=mean_bool(group,lambda r:r['correct_key']=='f')))
    out=DATA/'lure_descriptive.csv'
    with out.open('w',newline='',encoding='utf-8-sig') as f:
        writer=csv.DictWriter(f,fieldnames=FIELDS);writer.writeheader();writer.writerows(results)
    print(f'已导出 {out}，共{len(results)}组情绪×N×干扰条件的数据。')
    if not results:
        print('尚无本版本试次数据；完成预实验后重运行。')

if __name__=='__main__':main()

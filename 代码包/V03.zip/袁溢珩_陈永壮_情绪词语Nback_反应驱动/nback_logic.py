# -*- coding: utf-8 -*-
"""词语 N-back 随机生成、计分和等级判定（无 PsychoPy 依赖）。"""
from __future__ import annotations
import random
from statistics import NormalDist

WORDS = """苹果 书包 桌子 椅子 窗户 门口 河流 山谷 森林 草地 石头 纸张 铅笔 钢笔 橡皮 书本 地图 信封 钥匙 水杯 茶壶 碗筷 毛巾 牙刷 梳子 镜子 衣柜 衬衫 裤子 鞋子 袜子 手套 帽子 雨伞 皮箱 背包 电灯 台灯 电池 钟表 相机 电话 电脑 鼠标 键盘 屏幕 音箱 耳机 电线 书架 抽屉 地板 墙壁 屋顶 厨房 客厅 走廊 楼梯 电梯 公园 花园 树叶 花朵 树枝 花盆 湖泊 小溪 岛屿 海岸 沙滩 田野 小路 桥梁 马路 车站 火车 汽车 轮船 飞机 车轮 车票 纸箱 木箱 木板 铁门 玻璃 瓷砖 窗帘 被子 枕头 床单 地毯 篮子 盒子 瓶子 罐子 勺子 叉子 盘子 菜篮 稻谷 玉米 土豆 黄瓜 萝卜 竹子 橘子 香蕉 葡萄 梨子 桃子 西瓜""".split()


def validate_config(cfg: dict) -> None:
    required = ["max_n", "block_scored_trials", "matches_per_block", "repeat_blocks",
                "word_visible_seconds", "trial_total_seconds", "fixation_seconds",
                "emotion_image_seconds", "emotion_images_per_induction", "upgrade_accuracy_threshold"]
    for k in required:
        if k not in cfg:
            raise ValueError("配置文件缺少: " + k)
    if not 1 <= int(cfg["max_n"]) <= 8:
        raise ValueError("max_n 应为1至8")
    n = int(cfg["block_scored_trials"]); k = int(cfg["matches_per_block"])
    if n != 24 or k != 8:
        raise ValueError("试次数量或匹配数设置不合理")
    if not 0 < float(cfg['upgrade_accuracy_threshold']) <= 1:
        raise ValueError('upgrade_accuracy_threshold应在(0,1]内')
    if int(cfg["repeat_blocks"]) != 2:
        raise ValueError("稳定通过判定固定要求每级重复两个区块")
    if not 0 < cfg["word_visible_seconds"] < cfg["trial_total_seconds"]:
        raise ValueError("单词显示时长应小于整个试次时长")
    if not 0.2 <= float(cfg.get("feedback_seconds", 0)) <= 5.0:
        raise ValueError("feedback_seconds 应在0.2至5秒之间")
    if cfg["emotion_image_seconds"] <= 0 or cfg["emotion_images_per_induction"] < 1:
        raise ValueError("情绪图片诱导的时间或数量无效")
    for key in ("between_emotion_rest_seconds", "between_level_rest_seconds", "between_block_rest_seconds"):
        if float(cfg[key]) < 0:
            raise ValueError(key + "不能为负数")

def _category_schedule(n: int, rng: random.Random):
    """为24个计分试次产生恰好8匹配、8诱饵、8其他不匹配的随机序列。

    1-back需要避免紧跟真实匹配的2-back诱饵无法构造的问题；
    使用动态规划按可完成排列数量加权，而不是固定类别排列顺序。
    """
    from functools import lru_cache

    @lru_cache(None)
    def count(m, l, o, prev, first):
        if m + l + o == 0:
            return 1
        total = 0
        for kind, remaining in (("match", m), ("lure", l), ("other_nonmatch", o)):
            if remaining == 0 or (first and kind == "lure"):
                continue
            if n == 1 and prev == "match" and kind == "lure":
                continue
            nm, nl, no = m - (kind == "match"), l - (kind == "lure"), o - (kind == "other_nonmatch")
            total += count(nm, nl, no, kind, False)
        return total

    counts = {"match":8, "lure":8, "other_nonmatch":8}
    choices = []
    prev = ""
    for i in range(24):
        options=[]
        for kind, rem in counts.items():
            if rem == 0 or (i == 0 and kind == 'lure'):
                continue
            if n == 1 and prev == 'match' and kind == 'lure':
                continue
            nxt=counts.copy();nxt[kind]-=1
            ways=count(nxt['match'],nxt['lure'],nxt['other_nonmatch'],kind,False)
            if ways > 0:
                options.append((kind,ways))
        if not options:
            raise RuntimeError('N-back类别配额无法排列')
        pick=rng.randrange(sum(c for _,c in options))
        for kind,num in options:
            if pick < num:
                choices.append(kind); counts[kind]-=1; prev=kind
                break
            pick-=num
    return choices


def generate_block(n: int, scored_trials: int, matches: int,
                   rng: random.Random, words=None):
    """从10种固定候选词中生成N个启动词+24个计分词，精确8/8/8配额。

    - match: 当前词恰与前第N个中间词相同（J）；
    - lure: 当前词等于N±1位置的历史中间词，但不等于N位置（F）；
    - other_nonmatch: 当前词既不等于N位置，也不等于N±1位置（F）。
    启动词不计分。逐试次复核真实lag标签和诱饵位置。
    """
    if not 1 <= n <= 6:
        raise ValueError('N必须在1至6之间')
    if scored_trials != 24 or matches != 8:
        raise ValueError('当前预实验版本固定每区块24计分、8匹配、8诱饵、8其他不匹配')
    available=list(words if words is not None else WORDS)
    if len(set(available)) < 10:
        raise ValueError('候选总词库必须至少10种不重复词')
    # 只有传入10词池时直接使用；默认从完整112词库中选取10种。
    pool=available if len(available)==10 else rng.sample(available,10)
    if len(set(pool))!=10:
        raise ValueError('每区块词库必须包含10种不重复词')
    pool_field='|'.join(pool)

    for attempt in range(250):
        types=_category_schedule(n,rng)
        sequence=rng.sample(pool,n)  # N个不同的启动词，降低初始诱饵不可构造概率
        rows=[]
        for i,word in enumerate(sequence):
            rows.append(dict(trial_index=i+1,scored=False,word=word,is_match=False,
                             is_lure=False,trial_type='warmup',lure_lag='',
                             seen_before=False,correct_key='',candidate_pool=pool_field))
        feasible=True
        for kind in types:
            i=len(sequence)
            required=sequence[i-n]
            nearby=[]
            for lag in (n-1,n+1):
                if lag>=1 and i>=lag:
                    w=sequence[i-lag]
                    if w!=required and (w,lag) not in nearby:
                        nearby.append((w,lag))
            seen=set(sequence)
            if kind=='match':
                word=required; lure_lag=''
            elif kind=='lure':
                if not nearby:
                    feasible=False;break
                word,lure_lag=rng.choice(nearby)
            else:
                # 其他不匹配也不能碰巧成为N±1诱饵。
                forbidden={required} | {sequence[i-lag] for lag in (n-1,n+1)
                                        if lag>=1 and i>=lag}
                choices=[w for w in pool if w not in forbidden]
                if not choices:
                    feasible=False;break
                # 让每区块实际出现约8种以上不同词，而非只重复两三个。
                new_choices=[w for w in choices if w not in seen]
                if len(seen)<8 and new_choices:
                    choices=new_choices
                else:
                    old_choices=[w for w in choices if w in seen]
                    if old_choices:
                        choices=old_choices
                word=rng.choice(choices)
                lure_lag=''
            sequence.append(word)
            rows.append(dict(trial_index=i+1,scored=True,word=word,
                             is_match=(kind=='match'),is_lure=(kind=='lure'),
                             trial_type=kind,lure_lag=lure_lag,
                             seen_before=word in seen,
                             correct_key='j' if kind=='match' else 'f',
                             candidate_pool=pool_field))
        if not feasible:
            continue
        # 对真实刺激顺序进行独立验证，发现任何隐含/伪匹配都停止打包。
        for i,t in enumerate(rows):
            if not t['scored']:
                continue
            actual_match=t['word']==rows[i-n]['word']
            actual_lags={lag for lag in (n-1,n+1) if lag>=1 and i>=lag
                         and t['word']==rows[i-lag]['word']}
            if actual_match != t['is_match']:
                raise AssertionError('真实匹配标签与lag-N不一致')
            if t['trial_type']=='lure' and not (actual_lags and not actual_match):
                raise AssertionError('明确诱饵不是N±1位置重复')
            if t['trial_type']=='other_nonmatch' and actual_lags:
                raise AssertionError('其他不匹配出现未标记的N±1诱饵')
        if (len(set(x['word'] for x in rows))>=8 and
            {k:sum(x['trial_type']==k for x in rows) for k in
             ('match','lure','other_nonmatch')}==
            {'match':8,'lure':8,'other_nonmatch':8}):
            return rows
    raise RuntimeError(f'{n}-back词序列在250次尝试后仍不能满足8/8/8配额')


def distractor_pair(target_word: str, rng: random.Random, words=None):
    pool = list(words if words is not None else WORDS)
    pair = rng.sample([w for w in pool if w != target_word], 2)
    return pair[0], pair[1]


def signal_detection_metrics(trials):
    """Scored-trial metrics with log-linear correction for d-prime."""
    rows = [x for x in trials if x.get("scored", True)]
    targets = [x for x in rows if x["is_match"]]
    non_targets = [x for x in rows if not x["is_match"]]
    hit = sum(x.get("response_key") == "j" for x in targets)
    false_alarm = sum(x.get("response_key") == "j" for x in non_targets)
    miss = sum(x.get("response_key") != "j" for x in targets)
    correct_reject = sum(x.get("response_key") == "f" for x in non_targets)
    total = len(rows)
    correct = hit + correct_reject
    hit_rate = hit / len(targets) if targets else float("nan")
    fa_rate = false_alarm / len(non_targets) if non_targets else float("nan")
    balanced_acc = (hit_rate + 1 - fa_rate) / 2 if targets and non_targets else float("nan")
    if targets and non_targets:
        adj_hit = (hit + .5) / (len(targets) + 1)
        adj_fa = (false_alarm + .5) / (len(non_targets) + 1)
        z = NormalDist().inv_cdf
        dprime = z(adj_hit) - z(adj_fa)
    else:
        dprime = float("nan")
    rts = [float(x["rt"]) for x in rows if x.get("correct") and x.get("rt") not in (None, "")]
    return dict(scored_trials=total, n_targets=len(targets), n_nontargets=len(non_targets),
                hits=hit, misses=miss, false_alarms=false_alarm, correct_rejections=correct_reject,
                accuracy=correct / total if total else float("nan"), hit_rate=hit_rate,
                false_alarm_rate=fa_rate, balanced_accuracy=balanced_acc, dprime=dprime,
                mean_correct_rt=sum(rts)/len(rts) if rts else float("nan"),
                n_correct_rt=len(rts))



def joint_level_decision(blocks_by_condition: dict, cfg: dict) -> dict:
    """任一干扰条件的两区块合计准确率达到阈值则升级。

    两条件各2个24计分区块（各48个试次），分别统计；
    无干扰或有干扰任一准确率 >= 80% 即可升级。
    联合准确率仅作描述统计，不参与升级。
    """
    if set(blocks_by_condition) != {'with','without'}:
        raise ValueError('每个N等级必须同时测试有干扰和无干扰')
    output={}
    all_correct=all_total=0
    for cond in ('without','with'):
        blocks=blocks_by_condition[cond]
        if len(blocks) != int(cfg['repeat_blocks']):
            raise ValueError('条件缺少重复区块')
        total=sum(int(b['scored_trials']) for b in blocks)
        correct=sum(int(b['hits']) + int(b['correct_rejections']) for b in blocks)
        if total<=0 or correct>total:
            raise ValueError('区块得分数据不合理')
        output[f'{cond}_correct']=correct
        output[f'{cond}_scored']=total
        output[f'{cond}_accuracy']=correct/total
        all_correct+=correct
        all_total+=total
    # 对于两个条件等量试次，这等价于两条件正确率取算术平均。
    if output['with_scored'] != output['without_scored']:
        raise ValueError('两个条件试次数不同，无法直接等权平均；请检查区块设置')
    output['combined_correct']=all_correct
    output['combined_scored']=all_total
    output['combined_accuracy']=all_correct/all_total
    output['upgrade_threshold']=float(cfg['upgrade_accuracy_threshold'])
    output['without_pass']=output['without_accuracy']>=output['upgrade_threshold']
    output['with_pass']=output['with_accuracy']>=output['upgrade_threshold']
    output['level_pass']=output['without_pass'] or output['with_pass']
    return output

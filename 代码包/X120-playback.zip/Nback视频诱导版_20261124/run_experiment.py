# -*- coding: utf-8 -*-
"""情绪整体分组的词语N-back：每种情绪单独从1-back升级至最高6-back。

PsychoPy Coder 或 Builder 共用此程序；包含视频诱导、情绪评分及独立诱导预实验模式。
"""
from __future__ import annotations

import csv
import hashlib
import itertools
import json
import platform
import random
import re
import traceback
import math
import sys
from datetime import datetime
from pathlib import Path

from sequence_candidate import GENERATOR_VERSION
from nback_logic import (
    validate_config, generate_block, generate_matched_pair, distractor_pair, WORDS,
    signal_detection_metrics, joint_level_decision,
)

ROOT = Path(__file__).resolve().parent
VERSION = 'short_either85_seqv01_video120_30_ratings_20261124'
EMOTIONS = ('positive', 'neutral', 'negative')
EMOTION_ZH = {'positive':'积极', 'neutral':'中性', 'negative':'消极'}
DISTRACTOR_ZH = {'with':'有干扰', 'without':'无干扰'}

TRIAL_FIELDS = "participant order_index session emotion emotion_zh distractor_level distractor_zh n repetition trial_index scored word trial_type lure_lag lure_direction seen_before candidate_pool upper_distractor lower_distractor is_match is_lure correct_key response_key correct rt_seconds word_exposure_seconds trial_elapsed_seconds image_set video_path timestamp".split()
BLOCK_FIELDS = "participant order_index session emotion emotion_zh distractor_level distractor_zh n repetition candidate_pool match_trials lure_trials other_nonmatch_trials scored_trials n_targets n_nontargets hits misses false_alarms correct_rejections accuracy hit_rate false_alarm_rate balanced_accuracy dprime mean_correct_rt n_correct_rt response_rate block_accuracy_ge_threshold pair_seed pair_distance".split()
LEVEL_FIELDS = "participant order_index session emotion emotion_zh n without_correct without_scored without_accuracy with_correct with_scored with_accuracy combined_correct combined_scored combined_accuracy upgrade_threshold without_pass with_pass level_pass next_n timestamp".split()
SESSION_FIELDS = "participant order_index session emotion emotion_zh distractor_level distractor_zh highest_either_n last_tested_n accuracy_at_last_tested_n accuracy_at_highest_either_n reached_test_ceiling timestamp".split()
SUMMARY_FIELDS = "participant order_index emotion emotion_zh emotion_block highest_either_n last_tested_n combined_accuracy_at_last_n without_accuracy_at_last_n with_accuracy_at_last_n reached_test_ceiling both_completed".split()
VIDEO_FIELDS = "participant order_index session emotion emotion_zh n stage video_path sha256 target_seconds media_duration_seconds actual_elapsed_seconds volume status timestamp".split()
RATING_FIELDS = "participant order_index session emotion emotion_zh n stage valence arousal valence_rt_seconds arousal_rt_seconds timestamp".split()
PAIR_FIELDS = "participant order_index session emotion n pair_seed pair_distance without_signature with_signature assignment timestamp".split()
STAGE_FIELDS = "participant order_index emotion_block emotion stage n distractor repetition timestamp".split()
CONDITION_FIELDS = "participant order_index emotion emotion_zh emotion_block distractor_level distractor_zh highest_either_n last_tested_n accuracy_at_last_tested_n accuracy_at_highest_either_n reached_test_ceiling timestamp".split()


class StopExperiment(Exception):
    """用户按ESC结束。"""


def load_config():
    with (ROOT / 'config.json').open('r', encoding='utf-8') as f:
        cfg = json.load(f)
    validate_config(cfg)
    return cfg


def save_csv_row(path, fields, row):
    path.parent.mkdir(parents=True, exist_ok=True)
    new_file = not path.exists() or path.stat().st_size == 0
    with path.open('a', newline='', encoding='utf-8-sig') as f:
        writer = csv.DictWriter(f, fieldnames=fields, extrasaction='ignore')
        if new_file:
            writer.writeheader()
        writer.writerow({k: row.get(k, '') for k in fields})
        f.flush()


def choose_emotion_order(pid):
    """若被试编号以数字结尾，顺序按编号 mod 6；其余由稳定哈希分配。"""
    m = re.search(r'(\d+)$', pid)
    if m:
        return int(m.group(1)) % 6
    return int.from_bytes(hashlib.sha256(pid.encode('utf-8')).digest()[:4], 'big') % 6


def build_schedule(order_index):
    """返回三种情绪的完整区块顺序；每种情绪只出现一次。"""
    return list(itertools.permutations(EMOTIONS))[order_index]


def distraction_order(order_index, emotion_block, n):
    """在每个N等级下平衡先测有/无干扰，且不跨情绪切换。"""
    if (order_index + emotion_block + n) % 2:
        return ('without', 'with')
    return ('with', 'without')


def stage_row(paths, emotion_block, emotion, stage, n='', distractor='', repetition=''):
    save_csv_row(paths['stage_log'], STAGE_FIELDS, {
        'participant':paths['participant'], 'order_index':paths['order_index'],
        'emotion_block':emotion_block, 'emotion':emotion, 'stage':stage,
        'n':n, 'distractor':distractor, 'repetition':repetition,
        'timestamp':datetime.now().isoformat(timespec='seconds'),
    })


def video_path(emotion, phase):
    return ROOT/'stimuli'/'video'/f'{emotion}_{phase}.mp4'


def video_target(cfg, phase):
    return (float(cfg[f'emotion_{phase}_video_seconds']),
            float(cfg[f'emotion_{phase}_tolerance_seconds']))


def validate_video_duration(cfg, phase, actual):
    target,tolerance=video_target(cfg,phase)
    if not math.isfinite(actual) or abs(actual-target)>tolerance:
        raise ValueError(f'{phase} 视频长度 {actual:.2f}s；要求完整片段 {target-tolerance:g}–{target+tolerance:g}s。')
    return target


def check_video_files(cfg):
    files=[video_path(e,p) for e in EMOTIONS for p in ('initial','supplement')]
    missing=[str(p.relative_to(ROOT)) for p in files if not p.is_file() or p.stat().st_size==0]
    if missing:
        raise FileNotFoundError('缺少视频素材（不会回退至图片）：\n'+'\n'.join(missing)+'\n请参照 视频素材准备.md。')
    hashes={}
    for p in files:
        with p.open('rb') as f:
            h=hashlib.sha256()
            for chunk in iter(lambda:f.read(1024*1024),b''): h.update(chunk)
        hashes[str(p.relative_to(ROOT))]=h.hexdigest()
    if len(set(hashes.values())) != len(hashes):
        raise ValueError('六个视频文件中存在完全相同的文件，请检查类别及阶段。')
    return hashes


class UI:
    def __init__(self, cfg, existing_window=None):
        from psychopy import visual, core, event
        self.visual, self.core, self.event = visual, core, event
        self.current_movie = None
        self.cfg = cfg
        self.owns_window = existing_window is None
        self.font = cfg.get('font_override') or {
            'Windows': 'Microsoft YaHei', 'Darwin': 'PingFang SC',
            'Linux': 'Noto Sans CJK SC',
        }.get(platform.system(), 'Arial Unicode MS')
        self.win = existing_window or visual.Window(
            size=(cfg['window_width'],cfg['window_height']),
            fullscr=bool(cfg['fullscreen']), units='height',
            color=(-.83,-.85,-.89), allowGUI=True, waitBlanking=True,
        )
        self.head = visual.TextStim(self.win, text='', font=self.font, pos=(0,.29),
                                    height=.053, color='#F0F3F9', bold=True, wrapWidth=1.4)
        self.body = visual.TextStim(self.win, text='', font=self.font, pos=(0,.02),
                                    height=.039, color='#E6ECF4', wrapWidth=1.4, alignText='center')
        self.foot = visual.TextStim(self.win, text='', font=self.font, pos=(0,-.35),
                                    height=.025, color='#AFBCD0', wrapWidth=1.45)
        # 所有目标词与上下无关词：字体、字号、粗细、颜色完全一致。
        # 唯一可预测的目标区分线索为固定的屏幕中央位置。
        word_style = dict(font=self.font, height=.091, bold=True, color='#F5F5F5')
        self.center = visual.TextStim(self.win, text='', pos=(0, 0), **word_style)
        self.upper = visual.TextStim(self.win, text='', pos=(0, .20), **word_style)
        self.lower = visual.TextStim(self.win, text='', pos=(0, -.20), **word_style)
        self.fix = visual.TextStim(self.win, text='+', font=self.font, pos=(0,0),
                                   height=.070, color='#BDC9DB')
        self.feedback = visual.TextStim(self.win, text='', font=self.font, pos=(0,0),
                                        height=.096, bold=True, color='#20D473')
    def check_escape(self):
        if self.event.getKeys(keyList=['escape']):
            raise StopExperiment('ESC')

    def page(self, title, text, footer='按空格继续'):
        self.event.clearEvents(eventType='keyboard')
        self.head.text, self.body.text, self.foot.text = title, text, footer
        while True:
            self.head.draw(); self.body.draw(); self.foot.draw()
            self.win.flip()
            keys = self.event.getKeys(keyList=['space','escape'])
            if 'escape' in keys:
                raise StopExperiment('ESC')
            if 'space' in keys:
                return

    def rest(self, seconds):
        if seconds <= 0: return
        clock = self.core.Clock()
        while clock.getTime() < seconds:
            self.head.text = '请稍作休息'
            self.body.text = '下一组任务即将开始'
            self.foot.text = ''
            self.head.draw(); self.body.draw(); self.win.flip()
            self.check_escape()

    def open_movie(self, path):
        movie=self.visual.MovieStim(self.win, filename=str(path), movieLib='ffpyplayer',
                                    units='pix', loop=False, noAudio=False,
                                    volume=float(self.cfg['emotion_video_volume']),
                                    autoStart=False, autoLog=False)
        return movie

    @staticmethod
    def close_movie(movie):
        try:
            movie.stop()
        except AttributeError as error:
            # PsychoPy 2026.2.4 closes the reader, then reloads the movie
            # through a missing _freePlayer method. We never reuse the movie.
            if error.obj is not movie or error.name != '_freePlayer':
                raise
            movie._player = None
            movie._freeTextureBuffers()
            movie._isLoaded = False

    def preflight_videos(self):
        # 校验全部六段视频可打开、时长符合条件，且不播放给被试。
        for emotion in EMOTIONS:
            for phase in ('initial','supplement'):
                path=video_path(emotion,phase)
                movie=self.open_movie(path)
                try:
                    validate_video_duration(self.cfg,phase,float(movie.duration))
                    if min(movie.frameSize)<=0: raise ValueError(f'无法读取视频画面：{path}')
                finally:
                    UI.close_movie(movie)

    def play_video(self, path, phase):
        self.event.clearEvents(eventType='keyboard')
        movie=self.open_movie(path)
        self.current_movie=movie
        clock=self.core.Clock()
        try:
            duration=float(movie.duration)
            validate_video_duration(self.cfg,phase,duration)
            w,h=map(float,movie.frameSize)
            if min(w,h)<=0: raise ValueError('视频分辨率无效')
            ww,wh=map(float,self.win.size)
            scale=min(ww/w,wh/h)*.96
            movie.size=(w*scale,h*scale)
            movie.play()
            clock.reset()
            while not movie.isFinished:
                movie.draw(); self.win.flip(); self.check_escape()
                if clock.getTime()>duration+5:
                    raise RuntimeError(f'视频播放超时：{path}')
            elapsed=float(clock.getTime())
            if elapsed < duration-2:
                raise RuntimeError(f'视频提前结束：{path} ({elapsed:.2f}/{duration:.2f}s)')
            return duration,elapsed
        finally:
            try: UI.close_movie(movie)
            finally:
                self.current_movie=None
                self.win.flip()
                self.event.clearEvents(eventType='keyboard')

    def rating(self, dimension):
        # 非原版SAM图形量表；9级数字自评，不显示目标情绪。
        question,anchors={
            'valence':('你此刻感觉有多愉快或不愉快？','1＝非常不愉快    5＝中性    9＝非常愉快'),
            'arousal':('你此刻感觉有多平静或激动？','1＝非常平静    5＝中等    9＝非常激动')
        }[dimension]
        self.event.clearEvents(eventType='keyboard')
        clock=self.core.Clock()
        self.head.text='当前感受评分'
        self.body.text=question+'\n\n'+anchors+'\n\n1    2    3    4    5    6    7    8    9'
        self.foot.text='请按数字1–9，如实评价此刻感受；没有正确答案。'
        first=True
        digits=[str(i) for i in range(1,10)]
        while True:
            self.head.draw(); self.body.draw(); self.foot.draw(); self.win.flip()
            if first: clock.reset(); first=False
            keys=self.event.getKeys(keyList=digits+['num_'+k for k in digits]+['escape'])
            if 'escape' in keys: raise StopExperiment('ESC')
            for k in keys:
                k=k.removeprefix('num_')
                if k in digits: return int(k),float(clock.getTime())

    def fixation(self, seconds):
        clock = self.core.Clock()
        self.event.clearEvents(eventType='keyboard')
        while clock.getTime() < seconds:
            self.fix.draw(); self.win.flip(); self.check_escape()

    def word_trial(self, word, upper, lower, scored, correct_key):
        """反应驱动式词语试次：按键即反馈，不强制凑满反应窗。

        - 中央词最多显示 word_visible_seconds（默认1.0秒），随后若未按键显示十字；
        - 首次 F/J（不超过 trial_total_seconds=3.0秒）锁定回答和RT，
          下一次刷新即居中显示 Correct/Wrong，持续 feedback_seconds=0.5秒；
        - 超过反应截止仍未应答，记录漏答并显示红色 Wrong；
        - 不计分的前N个启动词仅显示1.0秒，不记录答案、不反馈；
        - 本函数结束后由 run_block() 统一显示0.7秒注视十字。

        注意：这是有意采用的反应驱动式SOA，非固定SOA。按键越早，
        下一个单词也会更早出现。feedback_seconds不计入RT。
        """
        visible_sec = float(self.cfg['word_visible_seconds'])
        deadline_sec = float(self.cfg['trial_total_seconds'])
        feedback_sec = float(self.cfg['feedback_seconds'])
        self.event.clearEvents(eventType='keyboard')
        clock = self.core.Clock()
        response, rt = '', ''
        feedback_started = None
        feedback_correct = False
        word_end_at = None

        # 第一次翻屏显示目标词后才重置计时，避免把准备绘图时间算入RT。
        self.center.text = word
        self.center.draw()
        if upper:
            self.upper.text, self.lower.text = upper, lower
            self.upper.draw(); self.lower.draw()
        self.win.flip()
        clock.reset()
        while True:
            elapsed = clock.getTime()
            for key, timestamp in self.event.getKeys(
                    keyList=['f', 'j', 'escape'], timeStamped=clock):
                if key == 'escape':
                    raise StopExperiment('ESC')
                if (scored and feedback_started is None
                        and 0 <= float(timestamp) <= deadline_sec):
                    response, rt = key, round(float(timestamp), 4)
                    feedback_correct = key == correct_key
                    feedback_started = clock.getTime()
                    break

            elapsed = clock.getTime()
            if scored and feedback_started is None and elapsed >= deadline_sec:
                feedback_started = elapsed
                feedback_correct = False

            if scored:
                if feedback_started is not None and elapsed - feedback_started >= feedback_sec:
                    break
                if feedback_started is not None:
                    self.feedback.text = 'Correct' if feedback_correct else 'Wrong'
                    self.feedback.color = '#20D473' if feedback_correct else '#FF4D5A'
                    self.feedback.pos = (0, 0)
                    self.feedback.draw()
                    drawing_word = False
                elif elapsed < visible_sec:
                    self.center.draw()
                    if upper:
                        self.upper.draw(); self.lower.draw()
                    drawing_word = True
                else:
                    self.fix.draw()
                    drawing_word = False
            else:
                if elapsed >= visible_sec:
                    break
                self.center.draw()
                if upper:
                    self.upper.draw(); self.lower.draw()
                drawing_word = True

            self.win.flip()
            # 从第一次实际改变画面的翻屏后测量词语暴露时间。
            if not drawing_word and word_end_at is None:
                word_end_at = clock.getTime()

        if word_end_at is None:
            word_end_at = clock.getTime()
        self.last_trial_timing = {
            'word_exposure_seconds': round(float(word_end_at), 4),
            'trial_elapsed_seconds': round(float(clock.getTime()), 4),
        }
        # 清空本试次反馈期间的F/J，不能影响下一试次。
        self.event.clearEvents(eventType='keyboard')
        return response, rt

    def close(self):
        if self.current_movie is not None:
            self.current_movie.stop()
            self.current_movie = None
        if self.owns_window:
            self.win.close()
            self.core.quit()


def participant_prompt():
    from psychopy import gui
    form={'被试编号':'001'}
    dialog=gui.DlgFromDict(dictionary=form, title='词语 N-back 实验', order=['被试编号'])
    if not dialog.OK: return None
    return form['被试编号']


def normalized_pid(raw):
    pid=re.sub(r'[^A-Za-z0-9_-]', '_', str(raw).strip())[:40]
    if not pid: raise ValueError('被试编号不能为空')
    return pid


def record_rating(ui, paths, emotion, session_idx, n, stage):
    val,vrt=ui.rating('valence'); aro,art=ui.rating('arousal')
    if not (1<=val<=9 and 1<=aro<=9): raise ValueError('情绪评分超出1–9')
    save_csv_row(paths['emotion_ratings'],RATING_FIELDS,{
        'participant':paths['participant'],'order_index':paths['order_index'],
        'session':session_idx,'emotion':emotion,'emotion_zh':EMOTION_ZH[emotion],
        'n':n,'stage':stage,'valence':val,'arousal':aro,
        'valence_rt_seconds':round(vrt,4),'arousal_rt_seconds':round(art,4),
        'timestamp':datetime.now().isoformat(timespec='milliseconds')})


def record_video(ui, paths, emotion, session_idx, n):
    phase='initial' if n==1 else 'supplement'
    path=video_path(emotion,phase); relative=str(path.relative_to(ROOT))
    duration,elapsed=ui.play_video(path,phase)
    save_csv_row(paths['video_log'],VIDEO_FIELDS,{
        'participant':paths['participant'],'order_index':paths['order_index'],
        'session':session_idx,'emotion':emotion,'emotion_zh':EMOTION_ZH[emotion],
        'n':n,'stage':phase,'video_path':relative,'sha256':paths['video_hashes'][relative],
        'target_seconds':video_target(ui.cfg,phase)[0],
        'media_duration_seconds':round(duration,4),'actual_elapsed_seconds':round(elapsed,4),
        'volume':ui.cfg['emotion_video_volume'],'status':'completed',
        'timestamp':datetime.now().isoformat(timespec='milliseconds')})
    return relative


def run_block(ui,rng,paths,session_idx,emotion,distraction,n,rep,image_set,
              prepared_rows=None, pair_seed='', pair_distance=''):
    cfg=ui.cfg
    if prepared_rows is None:
        # Standalone run_block() testing fallback; actual experiment supplies matched pairs.
        candidate_pool=rng.sample(WORDS,int(cfg['candidate_words_per_block']))
        ts=generate_block(n,int(cfg['block_scored_trials']),int(cfg['matches_per_block']),rng,words=candidate_pool)
    else:
        ts=prepared_rows
        candidate_pool=ts[0]['candidate_pool'].split('|')
        if (len(candidate_pool)!=int(cfg['candidate_words_per_block'])
            or len(ts)!=n+int(cfg['block_scored_trials'])
            or any(r['candidate_pool']!=ts[0]['candidate_pool'] for r in ts)):
            raise ValueError('已配对词序列的候选词库或试次数量异常')
    logged=[]
    for t in ts:
        ui.fixation(float(cfg['fixation_seconds']))
        upper,lower=distractor_pair(t['word'],rng,words=candidate_pool) if distraction=='with' else ('','')
        response,rt=ui.word_trial(t['word'],upper,lower,t['scored'],t['correct_key'])
        correct=(response==t['correct_key']) if t['scored'] else ''
        if t['scored']:
            logged.append({**t,'response_key':response,'correct':correct,'rt':rt})
        save_csv_row(paths['trials'],TRIAL_FIELDS,{
            'participant':paths['participant'],'order_index':paths['order_index'],
            'session':session_idx,'emotion':emotion,'emotion_zh':EMOTION_ZH[emotion],
            'distractor_level':distraction,'distractor_zh':DISTRACTOR_ZH[distraction],
            'n':n,'repetition':rep,'trial_index':t['trial_index'],
            'scored':t['scored'],'word':t['word'],
            'trial_type':t['trial_type'],'lure_lag':t['lure_lag'],
            'lure_direction':t.get('lure_direction',''),
            'seen_before':t['seen_before'],'candidate_pool':t['candidate_pool'],
            'upper_distractor':upper,'lower_distractor':lower,
            'is_match':t['is_match'] if t['scored'] else '',
            'is_lure':t['is_lure'] if t['scored'] else '',
            'correct_key':t['correct_key'],'response_key':response,
            'correct':correct,'rt_seconds':rt,
            'word_exposure_seconds':getattr(ui, 'last_trial_timing', {}).get('word_exposure_seconds', ''),
            'trial_elapsed_seconds':getattr(ui, 'last_trial_timing', {}).get('trial_elapsed_seconds', ''),
            'image_set':'', 'video_path':image_set,
            'timestamp':datetime.now().isoformat(timespec='seconds'),
        })
    m=signal_detection_metrics(logged)
    m['response_rate']=sum(bool(x['response_key']) for x in logged)/len(logged)
    # 是否达到本版85%阈值；每级有/无干扰各一个区块，任一条件达标即升级。
    meets=(m['accuracy']>=float(cfg['upgrade_accuracy_threshold']))
    save_csv_row(paths['blocks'],BLOCK_FIELDS,{
        'participant':paths['participant'],'order_index':paths['order_index'],
        'session':session_idx,'emotion':emotion,'emotion_zh':EMOTION_ZH[emotion],
            'distractor_level':distraction,'distractor_zh':DISTRACTOR_ZH[distraction],
        'n':n,'repetition':rep, 'candidate_pool':'|'.join(candidate_pool),
        'match_trials':8,'lure_trials':8,'other_nonmatch_trials':8,
        **m, 'block_accuracy_ge_threshold':meets,
        'pair_seed':pair_seed,'pair_distance':pair_distance,
    })
    return m


def block_description(n, emotion_block):
    return (f'词语任务 · 第 {emotion_block}/3 段 · {n}-back',
            f'判断中央单词是否与前面第 {n} 个单词相同：相同按 J，不同按 F。\n'
            '如果上下方出现其他单词，请忽略，只看中央单词。\n'
            f'每个区块的前 {n} 个单词用于准备，不用按键；其后作答会显示对错反馈。')


def run_emotion_ladder(ui, rng, paths, emotion_block, emotion):
    """只在当前情绪内从1到6逐级测试，任一干扰条件达到阈值即可升级。

    对每一个N，两个干扰条件各测一个完整区块（每区块24计分词）。
    计算无干扰24词的正确率和有干扰24词的正确率；两者联合准确率只描述。
    有干扰或无干扰任一条件正确率 >= 85%（至少21/24）则升级；均未达标时结束本情绪。
    每种情绪首次播放约120秒；升级后约30秒补充诱导。
    """
    cfg = ui.cfg
    level_rows = []
    highest = 0
    stage_row(paths, emotion_block, emotion, 'emotion_start')
    for n in range(1, int(cfg['max_n']) + 1):
        if n > 1:
            ui.rest(float(cfg['between_level_rest_seconds']))
        # Before induction, create the two independent but statistically matched
        # center-word sequences. Never reveal the matching score to the subject.
        pair_seed=rng.getrandbits(62)
        seq_a,seq_b,pair_info=generate_matched_pair(n,pair_seed,choices=int(cfg['sequence_pair_choices']))
        if rng.randrange(2):
            prepared_by_condition={'without':seq_a,'with':seq_b}
            assignment='A=without,B=with'
            signature_without=pair_info['A']; signature_with=pair_info['B']
        else:
            prepared_by_condition={'without':seq_b,'with':seq_a}
            assignment='A=with,B=without'
            signature_without=pair_info['B']; signature_with=pair_info['A']
        save_csv_row(paths['sequence_pairs'],PAIR_FIELDS,{
            'participant':paths['participant'],'order_index':paths['order_index'],
            'session':emotion_block,'emotion':emotion,'n':n,
            'pair_seed':pair_seed,'pair_distance':pair_info['distance'],
            'without_signature':json.dumps(signature_without,ensure_ascii=False),
            'with_signature':json.dumps(signature_with,ensure_ascii=False),
            'assignment':assignment,
            'timestamp':datetime.now().isoformat(timespec='seconds'),
        })
        record_rating(ui,paths,emotion,emotion_block,n,'pre_induction')
        stage_row(paths, emotion_block, emotion, 'induction_start', n)
        image_set = record_video(ui, paths, emotion, emotion_block, n)
        stage_row(paths, emotion_block, emotion, 'induction_end', n)
        record_rating(ui,paths,emotion,emotion_block,n,'post_induction')
        # 为避免刚看完图片就突然出现词语，保留独立准备页面。
        stage_row(paths, emotion_block, emotion, 'nback_ready_screen', n)
        ui.page(f'即将开始 {n}-back 任务',
                f'接下来进行 {n}-back 词语判断。\n'
                f'当前屏幕中间的目标词与前面第 {n} 个中间目标词相同按 J，不同按 F。\n'
                '若同时出现上、中、下三个词，请只判断最中间的词。',
                '准备好后，按空格开始')
        stage_row(paths, emotion_block, emotion, 'nback_ready_confirmed', n)
        stage_row(paths, emotion_block, emotion, 'level_start', n)

        blocks_by_condition = {}
        for distraction in distraction_order(paths['order_index'], emotion_block, n):
            blocks=[]
            condition_name=DISTRACTOR_ZH[distraction]
            condition_explain=('本组只呈现屏幕正中间的目标词。' if distraction=='without' else
                               '本组上、中、下同时出现三个相同字号的词。\n'
                               '请只看最中间的词；上下两个词不参与比较。')
            for rep in range(1,int(cfg['repeat_blocks'])+1):
                if rep>1:
                    ui.rest(float(cfg['between_block_rest_seconds']))
                stage_row(paths, emotion_block, emotion, 'block_ready_screen', n, distraction, rep)
                ui.page(f'{n}-back · {condition_name} · 第 {rep}/{cfg["repeat_blocks"]} 组',
                        f'接下来开始 {n}-back 的{condition_name}测试。\n'
                        f'{condition_explain}\n'
                        f'当前中间目标词与前面第 {n} 个中间目标词相同按 J，不同按 F。\n'
                        f'本组前 {n} 个词不计分、无需按键。',
                        '准备好后，按空格开始本组')
                stage_row(paths,emotion_block,emotion,'block_ready_confirmed',n,distraction,rep)
                if rep==1:
                    stage_row(paths,emotion_block,emotion,'condition_start',n,distraction)
                blocks.append(run_block(ui,rng,paths,emotion_block,emotion,
                                        distraction,n,rep,image_set,
                                        prepared_rows=prepared_by_condition[distraction],
                                        pair_seed=pair_seed, pair_distance=pair_info['distance']))
            blocks_by_condition[distraction]=blocks
            stage_row(paths, emotion_block, emotion, 'condition_end', n, distraction)

        decision=joint_level_decision(blocks_by_condition, cfg)
        decision_row={
            'participant':paths['participant'],'order_index':paths['order_index'],
            'session':emotion_block,'emotion':emotion,'emotion_zh':EMOTION_ZH[emotion],
            'n':n,**decision,
            'next_n':n+1 if decision['level_pass'] and n<int(cfg['max_n']) else '',
            'timestamp':datetime.now().isoformat(timespec='seconds')}
        save_csv_row(paths['level_results'], LEVEL_FIELDS, decision_row)
        level_rows.append(decision_row)
        if decision['level_pass']:
            highest=n
            stage_row(paths,emotion_block,emotion,'level_pass',n)
        else:
            stage_row(paths,emotion_block,emotion,'level_fail',n)
        stage_row(paths,emotion_block,emotion,'level_end',n)
        if not decision['level_pass']:
            break

    last=level_rows[-1]
    passed_level=next((r for r in level_rows if r['n']==highest),None)
    ceiling=highest==int(cfg['max_n'])
    for distraction in ('without','with'):
        key=distraction+'_accuracy'
        result_row={
            'participant':paths['participant'],'order_index':paths['order_index'],
            'session':emotion_block,'emotion_block':emotion_block,
            'emotion':emotion,'emotion_zh':EMOTION_ZH[emotion],
            'distractor_level':distraction,'distractor_zh':DISTRACTOR_ZH[distraction],
            'highest_either_n':highest,'last_tested_n':last['n'],
            'accuracy_at_last_tested_n':last[key],
            'accuracy_at_highest_either_n':passed_level[key] if passed_level else '',
            'reached_test_ceiling':ceiling,'timestamp':datetime.now().isoformat(timespec='seconds')}
        save_csv_row(paths['sessions'],SESSION_FIELDS,result_row)
        save_csv_row(paths['condition_results'],CONDITION_FIELDS,result_row)
    record_rating(ui,paths,emotion,emotion_block,last['n'],'emotion_end')
    stage_row(paths,emotion_block,emotion,'emotion_complete')
    return {'highest_either_n':highest,'last_level':last,'reached_test_ceiling':ceiling}


def run_experiment(participant_id=None, existing_window=None, show_intro=False, show_end=True, induction_only=False):
    cfg=load_config()
    if GENERATOR_VERSION!='candidate_v0.1_20261124':
        raise RuntimeError('新版词序生成器版本错误，请勿混用旧文件')
    video_hashes=check_video_files(cfg)
    print(f"N-back program version: {VERSION}; emotion outer loop, either condition >=85%, max N={cfg['max_n']}")
    if participant_id is None:
        participant_id=participant_prompt()
        if participant_id is None: return False
    pid=normalized_pid(participant_id)
    order_index=choose_emotion_order(pid)
    stamp=datetime.now().strftime('%Y%m%d_%H%M%S_%f')
    rng_seed=int.from_bytes(hashlib.sha256(f'{pid}:{stamp}'.encode('utf-8')).digest()[:8],'big')
    rng=random.Random(rng_seed)
    out=ROOT/('induction_pilot_data' if induction_only else 'data')/f'{pid}_{stamp}'
    out.mkdir(parents=True,exist_ok=True)
    paths={'participant':pid,'order_index':order_index,'video_hashes':video_hashes}
    for name in ('trials','blocks','level_results','sessions','summary','condition_results','video_log','emotion_ratings','stage_log','sequence_pairs'):
        paths[name]=out/f'{name}.csv'
    with (out/'run_manifest.json').open('w',encoding='utf-8') as f:
        json.dump({'participant':pid,'version':VERSION,'order_index':order_index,'seed':rng_seed,
                   'configuration':cfg,'stimuli_are_normed':False,
                   'mode':'induction_only' if induction_only else 'nback',
                   'video_sha256':video_hashes,
                   'rating_scale':'numeric self-report 1–9; valence and arousal; not original pictorial SAM',
                   'sequence_generator':GENERATOR_VERSION,
                   'matched_pair_choices':int(cfg['sequence_pair_choices']),
                   'order_rule':'each emotion fully 1..6 N, initial video before N1, supplement video before later N; pre/post ratings; either with or without >=85pct accuracy',
                   'emotion_order':list(build_schedule(order_index)),
                   'start_time':datetime.now().isoformat(timespec='seconds')},
                  f,ensure_ascii=False,indent=2)
    ui=None
    try:
        ui=UI(cfg,existing_window)
        ui.preflight_videos()
        # 简短的实验准备页；不恢复此前冗长的总体任务介绍。
        # Builder 通过 show_intro=False 调用本函数时仍然显示该准备页。
        stage_row(paths,0,'','experiment_ready_screen')
        ui.page('请被试准备实验',
                '准备好后按下空格键开始实验。',
                '')
        stage_row(paths,0,'','experiment_ready_confirmed')
        scores={}
        schedule=build_schedule(order_index)
        for emotion_block,emotion in enumerate(schedule,1):
            if emotion_block>1:
                ui.rest(float(cfg['between_emotion_rest_seconds']))
            # 本情绪从1-back逐级测试至有无干扰均未达85%，再切换情绪。
            if induction_only:
                # 独立检查两类视频；没有N-back，不产生能力数据。
                stage_row(paths,emotion_block,emotion,'emotion_start')
                for n in (1,2):
                    if n==2: ui.rest(float(cfg['between_level_rest_seconds']))
                    record_rating(ui,paths,emotion,emotion_block,n,'pre_induction')
                    stage_row(paths,emotion_block,emotion,'induction_start',n)
                    record_video(ui,paths,emotion,emotion_block,n)
                    stage_row(paths,emotion_block,emotion,'induction_end',n)
                    record_rating(ui,paths,emotion,emotion_block,n,'post_induction')
                record_rating(ui,paths,emotion,emotion_block,2,'emotion_end')
                stage_row(paths,emotion_block,emotion,'emotion_complete')
                continue
            scores[emotion]=run_emotion_ladder(ui,rng,paths,emotion_block,emotion)
            last=scores[emotion]['last_level']
            save_csv_row(paths['summary'],SUMMARY_FIELDS,{
                'participant':pid,'order_index':order_index,
                'emotion':emotion,'emotion_zh':EMOTION_ZH[emotion],
                'emotion_block':emotion_block,
                'highest_either_n':scores[emotion]['highest_either_n'],
                'last_tested_n':last['n'],
                'combined_accuracy_at_last_n':last['combined_accuracy'],
                'without_accuracy_at_last_n':last['without_accuracy'],
                'with_accuracy_at_last_n':last['with_accuracy'],
                'reached_test_ceiling':scores[emotion]['reached_test_ceiling'],
                'both_completed':True})
        if show_end:
            ui.page('实验完成','本次任务已结束。请稍作休息；如仍感到不适，请告知实验人员。','按空格结束')
        return True
    except StopExperiment as e:
        (out/'stopped.txt').write_text(str(e),encoding='utf-8')
        return False
    except Exception:
        err=traceback.format_exc()
        (out/'error_traceback.txt').write_text(err,encoding='utf-8')
        print(err)
        raise
    finally:
        if ui is not None:
            ui.close()


if __name__=='__main__':
    run_experiment(induction_only="--induction-only" in sys.argv)

"""用正式实验的播放器检查已配置的两段约 30 秒补充视频。"""

from run_experiment import StopExperiment, UI, load_config, video_path


def main():
    clips = [video_path(emotion, 'supplement') for emotion in ('positive', 'negative')]
    for clip in clips:
        if not clip.is_file() or clip.stat().st_size == 0:
            raise FileNotFoundError(clip)

    ui = UI(load_config())
    try:
        for clip in clips:
            duration, elapsed = ui.play_video(clip, 'supplement')
            print(f'{clip.name}: 媒体 {duration:.3f} 秒，实际播放 {elapsed:.3f} 秒', flush=True)
    except StopExperiment:
        print('已退出播放检查。')
        return 1
    finally:
        ui.win.close()
    return 0


if __name__ == '__main__':
    raise SystemExit(main())

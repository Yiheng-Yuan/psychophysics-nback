# -*- coding: utf-8 -*-
"""不依赖PsychoPy：检查即时反馈版run_block的原始试次CSV字段及指标。"""
import csv
import random
import tempfile
from pathlib import Path
import run_experiment as exp

class FakeUI:
    cfg = None
    last_trial_timing = {}
    def fixation(self, seconds):
        assert seconds == .7
    def word_trial(self, word, upper, lower, scored, correct_key):
        self.last_trial_timing = {'word_exposure_seconds': .412, 'trial_elapsed_seconds': .921}
        return (correct_key, .4) if scored else ('', '')

def main():
    ui=FakeUI(); ui.cfg=exp.load_config()
    with tempfile.TemporaryDirectory() as td:
        paths={'participant':'test','order_index':0,'trials':Path(td)/'trials.csv','blocks':Path(td)/'blocks.csv'}
        result=exp.run_block(ui,random.Random(123),paths,1,'positive','with',3,1,'testimg.jpg')
        assert result['accuracy']==1.0
        with paths['trials'].open(newline='',encoding='utf-8-sig') as f:
            rows=list(csv.DictReader(f))
        assert len(rows)==27
        scored=[x for x in rows if x['scored']=='True']
        assert len(scored)==24
        assert all(x['word_exposure_seconds']=='0.412' for x in rows)
        assert all(x['trial_elapsed_seconds']=='0.921' for x in rows)
        assert all(x['rt_seconds']=='0.4' for x in scored)
        assert all(x['distractor_zh']=='有干扰' for x in rows)
        assert sum(x['is_match']=='True' for x in scored)==8
        assert (paths['blocks']).exists()
        print('PASS: 试次级新增字段、对错、RT、干扰标签、区块统计均成功保存')
if __name__=='__main__':main()

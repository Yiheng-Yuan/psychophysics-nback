"""Mock media/clock test; no decoder, real display or audio hardware is used."""
from pathlib import Path
from tempfile import TemporaryDirectory
from types import SimpleNamespace
from unittest.mock import patch
import run_experiment as e
from test_feedback import SimTime, FakeClock, FakeWindow

class Movie:
    def __init__(self, duration):
        self.duration=duration; self.frameSize=(1920,1080); self.stopped=False
        self.origin=None; self.size=None
    def play(self): self.origin=SimTime.now
    @property
    def isFinished(self): return self.origin is not None and SimTime.now-self.origin>=self.duration
    def draw(self): pass
    def stop(self): self.stopped=True

def main():
    cfg=e.load_config()
    for p,d in [('initial',120),('supplement',30)]:
        assert e.validate_video_duration(cfg,p,d)==d
        for bad in (d-20,d+20,float('nan')):
            try: e.validate_video_duration(cfg,p,bad)
            except ValueError: pass
            else: raise AssertionError('invalid duration accepted')
        SimTime.now=0
        ui=e.UI.__new__(e.UI);ui.cfg=cfg;ui.win=FakeWindow();ui.win.size=(1280,800)
        ui.core=SimpleNamespace(Clock=FakeClock); ui.event=SimpleNamespace(clearEvents=lambda **kw:None)
        ui.check_escape=lambda:None
        m=Movie(d);ui.open_movie=lambda path:m
        dur,elapsed=ui.play_video(Path('mock.mp4'),p)
        assert dur==d and d<=elapsed<=d+.05 and m.stopped and ui.current_movie is None
        assert abs(m.size[0]/m.size[1]-1920/1080)<1e-9
        # abort must stop the audio/video player and clear current reference
        m=Movie(d);ui.open_movie=lambda path:m
        def abort(): raise e.StopExperiment('ESC')
        ui.check_escape=abort
        try: ui.play_video(Path('mock.mp4'),p)
        except e.StopExperiment: pass
        else: raise AssertionError('ESC ignored')
        assert m.stopped and ui.current_movie is None
    with TemporaryDirectory() as td, patch.object(e,'ROOT',Path(td)):
        try: e.check_video_files(cfg)
        except FileNotFoundError: pass
        else: raise AssertionError('missing clips accepted')
        for emotion in e.EMOTIONS:
            for phase in ('initial','supplement'):
                path=e.video_path(emotion,phase);path.parent.mkdir(parents=True,exist_ok=True)
                path.write_bytes(f'{emotion}_{phase}'.encode())
        assert len(e.check_video_files(cfg))==6
    print('PASS video duration, aspect ratio, full playback loop, ESC cleanup and missing media preflight (mocks only)')
if __name__=='__main__':main()

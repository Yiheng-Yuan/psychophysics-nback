# -*- coding: utf-8 -*-
"""兼容入口：完整情绪与干扰条件切换验证见test_logic.py。"""
from test_logic import main
if __name__ == '__main__': main()

# -*- coding: utf-8 -*-
"""独立诱导预实验：在PsychoPy Coder运行，不含N-back。"""
from run_experiment import run_experiment
if __name__=='__main__':
    run_experiment(induction_only=True)

# -*- coding: utf-8 -*-
"""输出每次诱导的前后评分与差值，分开正式和独立诱导数据。"""
import csv,json
from pathlib import Path
from run_experiment import VERSION
ROOT=Path(__file__).resolve().parent

def main():
    for sub in ('data','induction_pilot_data'):
        base=ROOT/sub
        if not base.exists(): continue
        out=[]
        for folder in sorted(base.iterdir()):
            if not folder.is_dir():continue
            manifest=folder/'run_manifest.json'; ratings=folder/'emotion_ratings.csv'
            if not manifest.exists() or not ratings.exists():continue
            if json.loads(manifest.read_text(encoding='utf-8')).get('version')!=VERSION:continue
            with ratings.open(encoding='utf-8-sig',newline='') as f: rr=list(csv.DictReader(f))
            grouped={}
            for r in rr:grouped.setdefault((r['emotion'],r['n']),{})[r['stage']]=r
            for (emotion,n),g in grouped.items():
                a,b=g.get('pre_induction'),g.get('post_induction')
                if not a or not b:continue
                end=g.get('emotion_end',{})
                out.append(dict(run=folder.name,participant=a['participant'],emotion=emotion,n=n,
                    pre_valence=a['valence'],post_valence=b['valence'],delta_valence=int(b['valence'])-int(a['valence']),
                    pre_arousal=a['arousal'],post_arousal=b['arousal'],delta_arousal=int(b['arousal'])-int(a['arousal']),
                    emotion_end_valence=end.get('valence',''),emotion_end_arousal=end.get('arousal','')))
        if out:
            dest=base/'induction_changes.csv'
            with dest.open('w',encoding='utf-8-sig',newline='') as f:
                w=csv.DictWriter(f,fieldnames=list(out[0]));w.writeheader();w.writerows(out)
            print(dest,len(out))
if __name__=='__main__':main()

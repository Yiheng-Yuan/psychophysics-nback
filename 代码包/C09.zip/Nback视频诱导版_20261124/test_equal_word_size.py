# -*- coding: utf-8 -*-
"""共享样式与版本一致性回归测试；不能替代PsychoPy真实画面验证。"""
import ast, json
from pathlib import Path
import xml.etree.ElementTree as ET
import run_experiment as exp

base=Path(__file__).resolve().parent
source=(base/'run_experiment.py').read_text(encoding='utf-8')
xml=(base/'experiment_builder.psyexp').read_text(encoding='utf-8')
ET.fromstring(xml)
assert exp.VERSION in xml, 'Builder版本与Python版本不一致'
assert xml.count(exp.VERSION)==1, 'Builder不应有多处不同版本标记'
assert source.count('word_style = dict(')==1
assert "color='#F5F5F5'" in source
assert 'height=.091, bold=True' in source
for name,position in [('center','(0, 0)'),('upper','(0, .20)'),('lower','(0, -.20)')]:
    expected=f'self.{name} = visual.TextStim(self.win, text=\'\', pos={position}, **word_style)'
    assert expected in source, (name, '未使用统一样式')
assert "'#B6C1D0'" not in source and "'#FAFBFF'" not in source
cfg=json.loads((base/'config.json').read_text(encoding='utf-8'))
assert cfg['max_n']==6 and cfg['feedback_seconds']==0.5 and cfg['fixation_seconds']==0.7
assert cfg['upgrade_accuracy_threshold']==0.85
print('PASS 三词同字体样式 / 无干扰中央词统一 / 版本一致 / 核心配置未变')

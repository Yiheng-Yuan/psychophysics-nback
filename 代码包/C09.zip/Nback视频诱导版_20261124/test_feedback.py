# -*- coding: utf-8 -*-
"""不依赖真实 PsychoPy 的虚拟显示/按键计时测试（不代表硬件显示时序验证）。"""
import json
import sys
import types
from pathlib import Path

import run_experiment as exp

ROOT = Path(__file__).resolve().parent

class SimTime:
    now = 0.0
    active_clock = None
    step = 0.025
    paints = []
    keys = []
    delivered = set()
    audio_actions = []

class FakeClock:
    def __init__(self):
        self.origin = SimTime.now
    def reset(self):
        self.origin = SimTime.now
        SimTime.active_clock = self
    def getTime(self):
        return SimTime.now - self.origin

class FakeStim:
    def __init__(self, win, text='', color=None, **kwargs):
        self.text = text
        self.color = color
        self.win = win
        self.pos = kwargs.get('pos', (0,0))
    def draw(self):
        SimTime.paints.append((SimTime.now, str(self.text), str(self.color), tuple(self.pos)))

class FakeImage(FakeStim):
    pass

class FakeWindow:
    def __init__(self):
        self.callbacks = []
    def callOnFlip(self, callback, *args, **kwargs):
        self.callbacks.append((callback,args,kwargs))
    def flip(self):
        SimTime.now += SimTime.step
        for callback,args,kwargs in self.callbacks:
            callback(*args,**kwargs)
        self.callbacks.clear()

class FakeSound:
    def __init__(self, filename, stereo=False, volume=1):
        self.filename=filename
        self.emotion=Path(filename).stem.split('_')[0]
        self.volume=volume
    def play(self):
        SimTime.audio_actions.append((SimTime.now, self.emotion, 'play'))
    def stop(self):
        SimTime.audio_actions.append((SimTime.now, self.emotion, 'stop'))

class FakeEvents:
    @staticmethod
    def clearEvents(eventType=None):
        return
    @staticmethod
    def getKeys(keyList=None, timeStamped=None):
        if timeStamped is None:
            return []
        elapsed = timeStamped.getTime()
        result = []
        for i, (offset, key) in enumerate(SimTime.keys):
            if i not in SimTime.delivered and elapsed >= offset:
                SimTime.delivered.add(i)
                if key in keyList:
                    result.append((key, offset))
        return result

psychopy = types.ModuleType('psychopy')
visual = types.ModuleType('psychopy.visual')
core = types.ModuleType('psychopy.core')
event = types.ModuleType('psychopy.event')
sound = types.ModuleType('psychopy.sound')
visual.TextStim = FakeStim
visual.ImageStim = FakeImage
core.Clock = FakeClock
event.getKeys = FakeEvents.getKeys
event.clearEvents = FakeEvents.clearEvents
sound.Sound = FakeSound
psychopy.visual, psychopy.core, psychopy.event, psychopy.sound = visual, core, event, sound
sys.modules.update({'psychopy': psychopy, 'psychopy.visual': visual,
                    'psychopy.core': core, 'psychopy.event': event, 'psychopy.sound': sound})

def check_case(label, scored, correct_key, events, expected_response, expected_feedback, expected_color, min_duration):
    SimTime.now = 0.0
    SimTime.paints = []
    SimTime.keys = events
    SimTime.delivered = set()
    cfg = json.loads((ROOT/'config.json').read_text(encoding='utf-8'))
    ui = exp.UI(cfg, FakeWindow())
    response, rt = ui.word_trial('苹果', '', '', scored, correct_key)
    assert response == expected_response, (label, response)
    if expected_response:
        assert rt == events[0][0], (label, rt)
    else:
        assert rt == '', (label, rt)
    assert SimTime.now + SimTime.step >= min_duration, (label, SimTime.now)
    fb = [(t,c,pos) for t,txt,c,pos in SimTime.paints if txt in ('Correct','Wrong')]
    if expected_feedback:
        assert fb, label
        assert all(c == expected_color for _,c,_ in fb), (label, fb[:2])
        assert all(pos == (0,0) for _,_,pos in fb), (label, fb[:2])
        texts = [txt for _,txt,_,_ in SimTime.paints if txt in ('Correct','Wrong')]
        assert texts and set(texts) == {expected_feedback}, (label,texts)
        assert fb[-1][0] - fb[0][0] >= cfg['feedback_seconds'] - 2*SimTime.step, (label, fb[-1], fb[0])
        # 提前按键后反馈立即在中心出现，且绝不与单词或干扰词同屏。
        if events and events[0][0] < cfg['word_visible_seconds']:
            pressed = events[0][0]
            assert fb[0][0] < pressed + 3*SimTime.step
            assert not any(txt=='苹果' and t >= fb[0][0]
                           for t,txt,_,_ in SimTime.paints), label
        # 任意有反馈的那一帧不得同时绘制目标词、外围词。
        frames_with_feedback = {round(t,5) for t,_,_ in fb}
        assert not any(txt in ('苹果','河流','桌子') and round(t,5) in frames_with_feedback
                       for t,txt,_,_ in SimTime.paints), label
    else:
        assert not fb, (label,fb)
    print('PASS', label, 'rt=',rt,'total_sec=',round(SimTime.now,3))

if __name__ == '__main__':
    cfg = json.loads((ROOT/'config.json').read_text(encoding='utf-8'))
    assert cfg['word_visible_seconds'] == 1.0
    assert cfg['trial_total_seconds'] == 3.0
    assert cfg['feedback_seconds'] == 0.5
    assert cfg['fixation_seconds'] == 0.7
    check_case('正确按键立即绿色并尽早进入下一刺激', True, 'j', [(0.45,'j')], 'j', 'Correct', '#20D473', 0.95)
    check_case('错误按键立即红色', True, 'f', [(0.45,'j')], 'j', 'Wrong', '#FF4D5A', 0.95)
    check_case('反应窗后段按键仍完整反馈', True, 'f', [(1.80,'f')], 'f', 'Correct', '#20D473', 2.30)
    check_case('3秒超时未按为红色', True, 'j', [], '', 'Wrong', '#FF4D5A', 3.50)
    check_case('启动词只显示1秒不反馈', False, '', [(0.45,'j')], '', None, None, 1.00)
    # 关键回归：早按键后不再为了原先的2.25秒强制等待。
    assert SimTime.now < cfg['trial_total_seconds']
    print('PASS: 反应驱动SOA、即刻居中反馈、3秒截止、无强制等待；非真实硬件验证')

# -*- coding: utf-8 -*-
"""词语 N-back 随机生成、计分和等级判定（无 PsychoPy 依赖）。"""
from __future__ import annotations
import random
from statistics import NormalDist

WORDS = """苹果 书包 桌子 椅子 窗户 门口 河流 山谷 森林 草地 石头 纸张 铅笔 钢笔 橡皮 书本 地图 信封 钥匙 水杯 茶壶 碗筷 毛巾 牙刷 梳子 镜子 衣柜 衬衫 裤子 鞋子 袜子 手套 帽子 雨伞 皮箱 背包 电灯 台灯 电池 钟表 相机 电话 电脑 鼠标 键盘 屏幕 音箱 耳机 电线 书架 抽屉 地板 墙壁 屋顶 厨房 客厅 走廊 楼梯 电梯 公园 花园 树叶 花朵 树枝 花盆 湖泊 小溪 岛屿 海岸 沙滩 田野 小路 桥梁 马路 车站 火车 汽车 轮船 飞机 车轮 车票 纸箱 木箱 木板 铁门 玻璃 瓷砖 窗帘 被子 枕头 床单 地毯 篮子 盒子 瓶子 罐子 勺子 叉子 盘子 菜篮 稻谷 玉米 土豆 黄瓜 萝卜 竹子 橘子 香蕉 葡萄 梨子 桃子 西瓜""".split()


def validate_config(cfg: dict) -> None:
    required = ["max_n", "block_scored_trials", "matches_per_block", "repeat_blocks",
                "word_visible_seconds", "trial_total_seconds", "fixation_seconds",
                "emotion_initial_video_seconds", "emotion_supplement_video_seconds", "emotion_initial_tolerance_seconds", "emotion_supplement_tolerance_seconds", "emotion_video_volume", "upgrade_accuracy_threshold"]
    for k in required:
        if k not in cfg:
            raise ValueError("配置文件缺少: " + k)
    if not 1 <= int(cfg["max_n"]) <= 6:
        raise ValueError("max_n 应为1至6")
    n = int(cfg["block_scored_trials"]); k = int(cfg["matches_per_block"])
    if n != 24 or k != 8:
        raise ValueError("试次数量或匹配数设置不合理")
    if not 0 < float(cfg['upgrade_accuracy_threshold']) <= 1:
        raise ValueError('upgrade_accuracy_threshold应在(0,1]内')
    if cfg.get('sequence_generator') != 'candidate_v0.1':
        raise ValueError('新版需要sequence_generator=candidate_v0.1')
    if not 1 <= int(cfg.get('sequence_pair_choices',0)) <= 10:
        raise ValueError('sequence_pair_choices应为1至10')
    if int(cfg["repeat_blocks"]) != 1:
        raise ValueError("短版固定每级每种干扰条件一个区块")
    if not 0 < cfg["word_visible_seconds"] < cfg["trial_total_seconds"]:
        raise ValueError("单词显示时长应小于整个试次时长")
    if not 0.2 <= float(cfg.get("feedback_seconds", 0)) <= 5.0:
        raise ValueError("feedback_seconds 应在0.2至5秒之间")
    for phase in ('initial','supplement'):
        duration=float(cfg[f'emotion_{phase}_video_seconds'])
        tolerance=float(cfg[f'emotion_{phase}_tolerance_seconds'])
        if not 0 <= tolerance < duration:
            raise ValueError('视频时长或容差无效')
    if not 0 < float(cfg['emotion_video_volume']) <= 1:
        raise ValueError('视频音量必须在(0,1]内')
    for key in ("between_emotion_rest_seconds", "between_level_rest_seconds", "between_block_rest_seconds"):
        if float(cfg[key]) < 0:
            raise ValueError(key + "不能为负数")

def audit_block(n: int, rows: list[dict]):
    """Verify the generated sequence before showing any stimuli to a participant."""
    from collections import Counter
    from sequence_candidate import VOCAB_COUNTS
    if len(rows)!=n+24 or sum(bool(r['scored']) for r in rows)!=24:
        raise ValueError('中央序列长度或计分标记不正确')
    seq=[r['word'] for r in rows]
    scored=rows[n:]
    if len(set(seq))!=VOCAB_COUNTS[n] or len(set(seq[:n]))!=n:
        raise ValueError('使用词种数不符合候选协议')
    if Counter(r['trial_type'] for r in scored)!=Counter({'match':8,'lure':8,'other_nonmatch':8}):
        raise ValueError('8/8/8配额错误')
    directions=Counter(r.get('lure_direction') for r in scored if r['trial_type']=='lure')
    target={'lure_plus':8} if n==1 else {'lure_minus':4,'lure_plus':4}
    if directions!=Counter(target):
        raise ValueError('N±1诱饵方向配额错误')
    for i, row in enumerate(rows):
        if row['trial_index']!=i+1 or bool(row['scored'])!=(i>=n):
            raise ValueError('试次索引错误')
        if i<n:continue
        is_target=seq[i]==seq[i-n]
        minus=n>1 and seq[i]==seq[i-(n-1)]
        plus=i>=n+1 and seq[i]==seq[i-(n+1)]
        if bool(row['is_match']) != is_target or row['correct_key']!=('j' if is_target else 'f'):
            raise ValueError(f'第{i+1}个词的N-back答案错误')
        typ=row['trial_type']
        if typ=='lure':
            if is_target or minus==plus:
                raise ValueError('诱饵方向不唯一或错误匹配')
            if row['lure_lag']!=(n-1 if minus else n+1):
                raise ValueError('诱饵lag错误')
        elif typ=='other_nonmatch':
            if is_target or minus or plus:raise ValueError('其他非匹配被误标为诱饵或目标')
        elif typ!='match' or not is_target:
            raise ValueError('目标试次分类错误')
    return True


def generate_block(n: int, scored_trials: int, matches: int,
                   rng: random.Random, words=None):
    """Produce one v0.1 sequence; preserve old calling signature for tests.

    For actual with/without comparisons, use generate_matched_pair() instead.
    """
    if scored_trials != 24 or matches != 8:
        raise ValueError('当前版本固定24计分、8匹配、8诱饵、8其他非目标')
    from sequence_candidate import generate_block as candidate_generate
    seed = rng.getrandbits(62)
    result = candidate_generate(n, seed, words=words)
    audit_block(n,result)
    return result


def generate_matched_pair(n: int, seed: int, choices: int = 3):
    """Return A/B sequences, plus audit signature and matching score.

    A/B both have 8+8+8 and balanced near lures (N>=2: 4+4).
    """
    from sequence_candidate import generate_matched_pair as candidate_pair
    a,b,info = candidate_pair(n, seed, choices=choices)
    audit_block(n,a); audit_block(n,b)
    if [r['word'] for r in a] == [r['word'] for r in b]:
        raise ValueError('两条件不应使用相同的中央词序列')
    return a,b,info


def distractor_pair(target_word: str, rng: random.Random, words=None):
    pool = list(words if words is not None else WORDS)
    pair = rng.sample([w for w in pool if w != target_word], 2)
    return pair[0], pair[1]


def signal_detection_metrics(trials):
    """Scored-trial metrics with log-linear correction for d-prime."""
    rows = [x for x in trials if x.get("scored", True)]
    targets = [x for x in rows if x["is_match"]]
    non_targets = [x for x in rows if not x["is_match"]]
    hit = sum(x.get("response_key") == "j" for x in targets)
    false_alarm = sum(x.get("response_key") == "j" for x in non_targets)
    miss = sum(x.get("response_key") != "j" for x in targets)
    correct_reject = sum(x.get("response_key") == "f" for x in non_targets)
    total = len(rows)
    correct = hit + correct_reject
    hit_rate = hit / len(targets) if targets else float("nan")
    fa_rate = false_alarm / len(non_targets) if non_targets else float("nan")
    balanced_acc = (hit_rate + 1 - fa_rate) / 2 if targets and non_targets else float("nan")
    if targets and non_targets:
        adj_hit = (hit + .5) / (len(targets) + 1)
        adj_fa = (false_alarm + .5) / (len(non_targets) + 1)
        z = NormalDist().inv_cdf
        dprime = z(adj_hit) - z(adj_fa)
    else:
        dprime = float("nan")
    rts = [float(x["rt"]) for x in rows if x.get("correct") and x.get("rt") not in (None, "")]
    return dict(scored_trials=total, n_targets=len(targets), n_nontargets=len(non_targets),
                hits=hit, misses=miss, false_alarms=false_alarm, correct_rejections=correct_reject,
                accuracy=correct / total if total else float("nan"), hit_rate=hit_rate,
                false_alarm_rate=fa_rate, balanced_accuracy=balanced_acc, dprime=dprime,
                mean_correct_rt=sum(rts)/len(rts) if rts else float("nan"),
                n_correct_rt=len(rts))



def joint_level_decision(blocks_by_condition: dict, cfg: dict) -> dict:
    """任一干扰条件的单区块准确率达到配置阈值则升级。

    两条件各1个24计分区块，分别统计；
    无干扰或有干扰任一准确率 >= 85%（至少21/24）即可升级。
    联合准确率仅作描述统计，不参与升级。
    """
    if set(blocks_by_condition) != {'with','without'}:
        raise ValueError('每个N等级必须同时测试有干扰和无干扰')
    output={}
    all_correct=all_total=0
    for cond in ('without','with'):
        blocks=blocks_by_condition[cond]
        if len(blocks) != int(cfg['repeat_blocks']):
            raise ValueError('条件缺少重复区块')
        total=sum(int(b['scored_trials']) for b in blocks)
        correct=sum(int(b['hits']) + int(b['correct_rejections']) for b in blocks)
        if total<=0 or correct>total:
            raise ValueError('区块得分数据不合理')
        output[f'{cond}_correct']=correct
        output[f'{cond}_scored']=total
        output[f'{cond}_accuracy']=correct/total
        all_correct+=correct
        all_total+=total
    # 对于两个条件等量试次，这等价于两条件正确率取算术平均。
    if output['with_scored'] != output['without_scored']:
        raise ValueError('两个条件试次数不同，无法直接等权平均；请检查区块设置')
    output['combined_correct']=all_correct
    output['combined_scored']=all_total
    output['combined_accuracy']=all_correct/all_total
    output['upgrade_threshold']=float(cfg['upgrade_accuracy_threshold'])
    output['without_pass']=output['without_accuracy']>=output['upgrade_threshold']
    output['with_pass']=output['with_accuracy']>=output['upgrade_threshold']
    output['level_pass']=output['without_pass'] or output['with_pass']
    return output

# -*- coding: utf-8 -*-
"""Non-graphical end-to-end assertion for paired center sequences and CSV logs."""
from collections import Counter
from pathlib import Path
from random import Random
from tempfile import TemporaryDirectory
import csv
import run_experiment as exp
from nback_logic import generate_matched_pair
from sequence_candidate import VOCAB_COUNTS

class FakeUI:
    def __init__(self):
        self.cfg=exp.load_config()
        self.last_trial_timing={}
    def fixation(self,seconds):
        assert seconds==.7
    def word_trial(self,word,upper,lower,scored,correct_key):
        self.last_trial_timing={'word_exposure_seconds':0.71,'trial_elapsed_seconds':1.31}
        if upper:
            assert upper!=lower and upper!=word and lower!=word
        return (correct_key,.6) if scored else ('','')

def load(path):
    with path.open(encoding='utf-8-sig',newline='') as f:
        return list(csv.DictReader(f))

def main():
    ui=FakeUI();ntrials=0
    with TemporaryDirectory() as tmp:
        for n in range(1,7):
            a,b,info=generate_matched_pair(n,seed=n*7831+11,choices=3)
            assert [r['word'] for r in a] != [r['word'] for r in b]
            for condition,seq in (('without',a),('with',b)):
                root=Path(tmp)/f'{n}_{condition}'
                root.mkdir()
                paths={'participant':'test','order_index':0,
                       'trials':root/'trials.csv','blocks':root/'blocks.csv'}
                result=exp.run_block(ui,Random(n*141),paths,1,'neutral',condition,n,1,'test.jpg',
                                     prepared_rows=seq,pair_seed=n*7831+11,
                                     pair_distance=info['distance'])
                assert result['accuracy']==1.0
                trials=load(paths['trials']); blocks=load(paths['blocks'])
                assert len(trials)==n+24 and len(blocks)==1
                centers=[r['word'] for r in trials]
                assert len(set(centers))==VOCAB_COUNTS[n]
                types=Counter(r['trial_type'] for r in trials if r['scored']=='True')
                assert types == {'match':8,'lure':8,'other_nonmatch':8},(n,types)
                dirs=Counter(r['lure_direction'] for r in trials if r['trial_type']=='lure')
                assert dirs == ({'lure_plus':8} if n==1 else {'lure_minus':4,'lure_plus':4}), (n,dirs)
                for i,row in enumerate(trials):
                    assert row['word']==seq[i]['word']
                    if i>=n:
                        assert (row['correct_key']=='j')==(centers[i]==centers[i-n])
                assert float(blocks[0]['pair_distance'])==info['distance']
                assert blocks[0]['candidate_pool']==seq[0]['candidate_pool']
                ntrials+=24
            print('PASS integrated paired',n,'-back')
    assert ntrials==6*2*24
    print('PASS all integrated sequence/CSV/distractors for 12 blocks; scored',ntrials)

if __name__=='__main__':main()

# -*- coding: utf-8 -*-
"""新版本词序列穷核：独立核对8匹配/8诱饵/8其他、lag位置与策略上限。
无 PsychoPy 依赖，不验证真实键盘/显示器时序。
"""
from collections import Counter
import random
from nback_logic import generate_block, WORDS


def main():
    count=0
    for n in range(1,7):
        for seed in range(12):
            rng=random.Random((n<<16)+seed)
            pool=rng.sample(WORDS,10)
            trials=generate_block(n,24,8,rng,words=pool)
            assert len(trials)==24+n
            assert all(t['candidate_pool']=='|'.join(pool) for t in trials)
            assert set(t['word'] for t in trials).issubset(pool)
            assert len(set(t['word'] for t in trials)) == {1:8,2:5,3:6,4:7,5:7,6:8}[n]
            scored=[t for t in trials if t['scored']]
            assert Counter(t['trial_type'] for t in scored)=={'match':8,'lure':8,'other_nonmatch':8}
            all_f=sum(t['correct_key']=='f' for t in scored)/24
            familiarity=sum((('j' if t['seen_before'] else 'f')==t['correct_key'])
                            for t in scored)/24
            assert all_f==16/24
            assert familiarity<=16/24, (n,seed,familiarity)
            for i,t in enumerate(trials):
                if not t['scored']:
                    assert t['trial_type']=='warmup' and t['correct_key']==''
                    continue
                m=(trials[i]['word']==trials[i-n]['word'])
                near={lag for lag in (n-1,n+1) if lag>=1 and i>=lag
                      and trials[i]['word']==trials[i-lag]['word']}
                assert t['is_match']==m
                assert t['correct_key']==('j' if m else 'f')
                if t['trial_type']=='lure':
                    assert (not m) and near and t['lure_lag'] in near
                elif t['trial_type']=='other_nonmatch':
                    assert (not m) and not near
                assert t['seen_before']==(t['word'] in [x['word'] for x in trials[:i]])
            count+=1
        print(f'PASS: {n}-back, 12个随机区块，配额/标签/熟悉性策略检查通过')
    print(f'PASS: 共{count}个区块、{count*24}个计分试次；全部按F和完美熟悉性策略的理论正确率均≤66.7%')

if __name__=='__main__':
    main()

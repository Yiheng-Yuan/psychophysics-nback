# -*- coding: utf-8 -*-
"""Validated sequence candidate v0.1 integrated into the PsychoPy short experiment.

Pure Python, generating 1..6-back sequences with target/lure/other quotas.
This is an exploratory protocol (not a universal N-back standard).
"""
from __future__ import annotations
from collections import Counter
from dataclasses import dataclass
import math
import random
import time

GENERATOR_VERSION = 'candidate_v0.1_20261124'

VOCAB_COUNTS = {1:8, 2:5, 3:6, 4:7, 5:7, 6:8}
HARD_TWO_WORD_LIMIT = {n:6 for n in range(2,7)}  # any six centers require >=3 different words
QUOTA = {1:(8,8,8), **{n:(8,4,4,8) for n in range(2,7)}}
LABELS = {1:("match","lure_plus","other_nonmatch"),
          **{n:("match","lure_minus","lure_plus","other_nonmatch") for n in range(2,7)}}

@dataclass(frozen=True)
class Partial:
    seq: tuple[int, ...]
    used: tuple[int, ...]
    cats: tuple[str, ...]
    cost: float


def category_for(seq: tuple[int, ...], n: int, word: int) -> str | None:
    i = len(seq)
    if word == seq[i-n]:
        return 'match'
    minus = n>1 and i>=n-1 and word == seq[i-(n-1)]
    plus = i>=n+1 and word == seq[i-(n+1)]
    if minus and plus:
        return None  # ambiguous direction, never count same trial twice
    if minus: return 'lure_minus'
    if plus: return 'lure_plus'
    return 'other_nonmatch'


def _increment_cost(seq: tuple[int, ...], cats: tuple[str, ...], word: int,
                    kind: str, scored_index: int, new: bool) -> float:
    # Soft objectives: not universal requirements. Penalties do not alter correctness.
    recent6 = seq[-5:] + (word,)
    recent8 = seq[-7:] + (word,)
    cost = 0.0
    if len(recent6) == 6 and len(set(recent6))<=2:
        cost += 12.0
    if len(recent8) == 8 and len(set(recent8))<=3:
        cost += 5.0
    if len(seq)>=3 and word==seq[-3]: cost += .7
    if len(seq)>=4 and word==seq[-4]: cost += .2
    # Avoid one lexical item dominating the block.
    freq = seq.count(word)
    cost += .11 * (freq + 1)**2
    if scored_index >= 1 and len(cats) >= 3 and cats[-1]==cats[-2]==kind:
        cost += .8
    if kind != 'match' and len(cats)>=4 and all(x!='match' for x in cats[-4:]):
        cost += 4.5
    return cost


def _generate_one(n: int, rng: random.Random, beam_width: int):
    vocabulary_count = VOCAB_COUNTS[n]
    labels = LABELS[n]
    quotas = QUOTA[n]
    max_occurrence = 7 if n==2 else (8 if n<=3 else 7)
    start = Partial(tuple(range(n)), tuple(0 for _ in labels), tuple(), 0.)
    beam = [start]
    for t in range(24):
        proposals = []
        for state in beam:
            freq = Counter(state.seq)
            old = tuple(sorted(freq))
            # New symbols canonicalized to the first unused ID. The actual
            # Chinese words are sampled at the end so search is more efficient.
            available = old + ((len(old),) if len(old)<vocabulary_count else ())
            for word in available:
                new = word not in freq
                if new and (state.cats and state.seq[-1] not in state.seq[:len(state.seq)-1]):
                    continue  # no adjacent scored first-occurrences
                if freq[word] >= max_occurrence:
                    continue
                if len(state.seq)>=2 and state.seq[-1]==state.seq[-2]==word:
                    continue
                if n >= 3 and word == state.seq[-1]:
                    continue  # no immediate center repeats for high N
                if n in HARD_TWO_WORD_LIMIT and len(state.seq)>=HARD_TWO_WORD_LIMIT[n]-1 and len(set(state.seq[-(HARD_TWO_WORD_LIMIT[n]-1):] + (word,)))<=2:
                    continue
                kind = category_for(state.seq,n,word)
                if kind not in labels:
                    continue
                ki = labels.index(kind)
                if state.used[ki] >= quotas[ki]:
                    continue
                used = list(state.used); used[ki] += 1
                new_used = len(old)+int(new)
                # Only other nonmatches can introduce new words.
                missing_new = vocabulary_count - new_used
                remaining_others = quotas[labels.index('other_nonmatch')] - used[labels.index('other_nonmatch')]
                if missing_new > remaining_others:
                    continue
                next_t = t+1
                # Mild encouragement to distribute novel words across time.
                ideal_new = (vocabulary_count - n) * (next_t / 24)
                pacing = .18 * abs((new_used-n)-ideal_new)
                cost = state.cost + _increment_cost(state.seq, state.cats, word,kind,t,new) + pacing
                proposal = Partial(state.seq + (word,), tuple(used), state.cats + (kind,), cost)
                # Stochastic beam diversity, not tied to fixed recurrence rules.
                proposals.append((cost + rng.gauss(0, 2.7), rng.random(), proposal))
        if not proposals:
            return None
        proposals.sort(key=lambda e:(e[0],e[1]))
        beam = [p for _,_,p in proposals[:beam_width]]
    final = [s for s in beam if s.used==quotas and len(set(s.seq))==vocabulary_count]
    if not final:
        return None
    return min(final,key=lambda s:s.cost)



def _generate_1back_with_legacy_logic(rng: random.Random, pool: list[str]) -> list[dict]:
    """N=1 is deliberately NOT redesigned here. Reuse and locally rank the
    original 85%-short-version generator; reducing its vocabulary from 8 to
    5 caused long two-word loops in independent feasibility trials.

    No graphics or PsychoPy are involved. This path remains a documented
    limitation; unlike N=2..6 its category scheduler retains the legacy
    cap on four consecutive F responses.
    """
    import baseline_nback_logic
    options = []
    for _ in range(8):
        try:
            rows = baseline_nback_logic.generate_block(1,24,8,random.Random(rng.getrandbits(64)),words=pool)
        except RuntimeError:
            continue
        seq = [r['word'] for r in rows]
        windows6 = sum(len(set(seq[i:i+6]))<=2 for i in range(len(seq)-5))
        windows8 = sum(len(set(seq[i:i+8]))<=3 for i in range(len(seq)-7))
        freq = max(Counter(seq).values())
        options.append(((windows6,windows8,freq),rows))
    if not options:
        raise RuntimeError('1-back baseline could not generate a valid block')
    rows = min(options,key=lambda a:a[0])[1]
    for row in rows:
        row['lure_direction'] = 'lure_plus' if row['trial_type']=='lure' else ''
    return rows

def generate_block(n: int, seed: int, words: list[str]|None=None,
                   beam_width: int=200, retries: int=4) -> list[dict]:
    if n not in VOCAB_COUNTS: raise ValueError('N must be 1..6')
    if words is None:
        # Import original list only when available. This prototype remains
        # standalone with its bundled original word list.
        from pathlib import Path
        words = Path(__file__).with_name('words.txt').read_text(encoding='utf-8').split()
    if len(set(words))<10: raise ValueError('At least 10 distinct candidate words required')
    rng = random.Random(seed)
    pool = (list(dict.fromkeys(words)) if len(set(words)) == 10
            else rng.sample(list(dict.fromkeys(words)),10))
    if n==1:
        return _generate_1back_with_legacy_logic(rng, pool)
    solution = None
    best_rank = None
    # For 2-back, inspect several full candidates instead of imposing a
    # deterministic maximum-F-run rule. A hard rule would make a long F streak
    # predict the next J answer. Other N levels normally produce short F runs.
    draws = max(3, retries) if n==2 else retries
    for attempt in range(draws):
        trial = _generate_one(n,rng,beam_width if attempt < 3 else beam_width*(attempt-1))
        if trial is None:
            continue
        f_streak = max(map(len, ''.join('F' if cat!='match' else 'J' for cat in trial.cats).split('J')))
        rank = (f_streak,trial.cost) if n==2 else (trial.cost,)
        if solution is None or rank < best_rank:
            solution, best_rank = trial, rank
        if n!=2:
            break
    if solution is None:
        raise RuntimeError(f'No valid {n}-back sequence for seed={seed}, beam={beam_width}, retries={retries}')
    chosen = rng.sample(pool, VOCAB_COUNTS[n])
    seq = [chosen[k] for k in solution.seq]
    rows = []
    for i,word in enumerate(seq):
        scored = i>=n
        kind = solution.cats[i-n] if scored else 'warmup'
        lag = (n-1 if kind=='lure_minus' else n+1 if kind=='lure_plus' else '')
        seen = word in seq[:i]
        rows.append(dict(trial_index=i+1, scored=scored, word=word,
                         trial_type='lure' if kind.startswith('lure') else kind,
                         lure_direction=kind if kind.startswith('lure') else '',
                         lure_lag=lag, is_match=kind=='match',
                         is_lure=kind.startswith('lure'), seen_before=seen,
                         correct_key='j' if kind=='match' else 'f' if scored else '',
                         candidate_pool='|'.join(pool)))
    return rows


def block_signature(rows: list[dict]) -> dict:
    """Statistics for matching two independently generated center sequences."""
    n=sum(not r['scored'] for r in rows)
    seq=[r['word'] for r in rows]
    scored=rows[n:]
    earlier=[r for r in scored[:12]]
    gaps=[]
    for i, r in enumerate(rows):
        if i>=n and r['trial_type']=='other_nonmatch' and r['seen_before']:
            prior=max(j for j in range(i) if seq[j]==seq[i])
            gaps.append(i-prior)
    return {
       'first12_match':sum(r['is_match'] for r in earlier),
       'first12_lure_minus':sum(r['lure_direction']=='lure_minus' for r in earlier),
       'first12_lure_plus':sum(r['lure_direction']=='lure_plus' for r in earlier),
       'new_first12':sum(not r['seen_before'] for r in earlier),
       'max_frequency':max(Counter(seq).values()),
       'longest_f_run':max(map(len, ''.join('F' if r['correct_key']=='f' else 'J' for r in scored).split('J'))),
       'old_other_mean_gap':sum(gaps)/len(gaps) if gaps else 0,
    }


def pair_distance(a: dict,b: dict) -> float:
    weights={'first12_match':2.0,'first12_lure_minus':1.8,
             'first12_lure_plus':1.8,'new_first12':1.8,
             'max_frequency':.65,'longest_f_run':.35,
             'old_other_mean_gap':.5}
    return round(sum(weights[k]*abs(a[k]-b[k]) for k in weights),6)


def generate_matched_pair(n:int, seed:int, choices:int=5) -> tuple[list[dict], list[dict], dict]:
    """Independent center sequences; similarity is statistical, NOT identical trial order.

    The experiment assigns A/B randomly to with/without distraction.
    """
    if choices<1:raise ValueError('choices>=1 required')
    rng=random.Random(seed)
    one=[generate_block(n,rng.getrandbits(62)) for _ in range(choices)]
    two=[generate_block(n,rng.getrandbits(62)) for _ in range(choices)]
    info1=[block_signature(b) for b in one]
    info2=[block_signature(b) for b in two]
    best=min(((pair_distance(a,b),i,j) for i,a in enumerate(info1) for j,b in enumerate(info2)))
    dist,i,j=best
    return one[i],two[j],{'distance':dist,'A':info1[i],'B':info2[j],
                         'candidate_pairs_compared':choices*choices}

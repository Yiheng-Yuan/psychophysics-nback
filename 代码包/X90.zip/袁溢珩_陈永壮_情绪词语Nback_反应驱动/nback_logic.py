# -*- coding: utf-8 -*-
"""词语 N-back 随机生成、计分和等级判定（无 PsychoPy 依赖）。"""
from __future__ import annotations
import random
from statistics import NormalDist

WORDS = """苹果 书包 桌子 椅子 窗户 门口 河流 山谷 森林 草地 石头 纸张 铅笔 钢笔 橡皮 书本 地图 信封 钥匙 水杯 茶壶 碗筷 毛巾 牙刷 梳子 镜子 衣柜 衬衫 裤子 鞋子 袜子 手套 帽子 雨伞 皮箱 背包 电灯 台灯 电池 钟表 相机 电话 电脑 鼠标 键盘 屏幕 音箱 耳机 电线 书架 抽屉 地板 墙壁 屋顶 厨房 客厅 走廊 楼梯 电梯 公园 花园 树叶 花朵 树枝 花盆 湖泊 小溪 岛屿 海岸 沙滩 田野 小路 桥梁 马路 车站 火车 汽车 轮船 飞机 车轮 车票 纸箱 木箱 木板 铁门 玻璃 瓷砖 窗帘 被子 枕头 床单 地毯 篮子 盒子 瓶子 罐子 勺子 叉子 盘子 菜篮 稻谷 玉米 土豆 黄瓜 萝卜 竹子 橘子 香蕉 葡萄 梨子 桃子 西瓜""".split()


def validate_config(cfg: dict) -> None:
    required = ["max_n", "block_scored_trials", "matches_per_block", "repeat_blocks",
                "word_visible_seconds", "trial_total_seconds", "fixation_seconds",
                "emotion_image_seconds", "emotion_images_per_induction", "upgrade_accuracy_threshold"]
    for k in required:
        if k not in cfg:
            raise ValueError("配置文件缺少: " + k)
    if not 1 <= int(cfg["max_n"]) <= 8:
        raise ValueError("max_n 应为1至8")
    n = int(cfg["block_scored_trials"]); k = int(cfg["matches_per_block"])
    if n != 24 or k != 8:
        raise ValueError("试次数量或匹配数设置不合理")
    if not 0 < float(cfg['upgrade_accuracy_threshold']) <= 1:
        raise ValueError('upgrade_accuracy_threshold应在(0,1]内')
    if int(cfg["repeat_blocks"]) != 2:
        raise ValueError("稳定通过判定固定要求每级重复两个区块")
    if not 0 < cfg["word_visible_seconds"] < cfg["trial_total_seconds"]:
        raise ValueError("单词显示时长应小于整个试次时长")
    if not 0.2 <= float(cfg.get("feedback_seconds", 0)) <= 5.0:
        raise ValueError("feedback_seconds 应在0.2至5秒之间")
    if cfg["emotion_image_seconds"] <= 0 or cfg["emotion_images_per_induction"] < 1:
        raise ValueError("情绪图片诱导的时间或数量无效")
    for key in ("between_emotion_rest_seconds", "between_level_rest_seconds", "between_block_rest_seconds"):
        if float(cfg[key]) < 0:
            raise ValueError(key + "不能为负数")

def _category_schedule(n: int, rng: random.Random):
    """精确8/8/8并限制类别集中：不出现连续3个同类、连续5个F。

    对1-back，紧接match不能安排2-back lure，因为lag-1和lag-2
    已经是同一个词。按合法排列数加权抽样，避免高N等级与低N等级
    因拒绝采样导致类别顺序偏差。
    """
    from functools import lru_cache

    @lru_cache(None)
    def count(m, l, o, prev, same_run, f_run):
        if m + l + o == 0:
            return 1
        total = 0
        for kind, remaining in (("match", m), ("lure", l), ("other_nonmatch", o)):
            if (not remaining or (not prev and kind == 'lure') or
                (n == 1 and prev == 'match' and kind in ('match','lure')) or
                (n == 1 and prev == 'other_nonmatch' and kind == 'other_nonmatch')):
                continue
            next_same = same_run + 1 if kind == prev else 1
            next_f = f_run + 1 if kind != "match" else 0
            if next_same > 2 or next_f > 4:
                continue
            total += count(m - (kind == 'match'), l - (kind == 'lure'),
                           o - (kind == 'other_nonmatch'), kind, next_same, next_f)
        return total

    remaining = {'match': 8, 'lure': 8, 'other_nonmatch': 8}
    result = []
    prev = ''
    same_run = f_run = 0
    for _ in range(24):
        choices = []
        for kind, rem in remaining.items():
            if (not rem or (not prev and kind == 'lure') or
                (n == 1 and prev == 'match' and kind in ('match','lure')) or
                (n == 1 and prev == 'other_nonmatch' and kind == 'other_nonmatch')):
                continue
            next_same = same_run + 1 if prev == kind else 1
            next_f = f_run + 1 if kind != 'match' else 0
            if next_same > 2 or next_f > 4:
                continue
            future = remaining.copy(); future[kind] -= 1
            ways = count(future['match'], future['lure'], future['other_nonmatch'],
                         kind, next_same, next_f)
            if ways:
                choices.append((kind, ways, next_same, next_f))
        total = sum(w for _, w, _, _ in choices)
        if not total:
            raise RuntimeError('不存在满足重复约束的8/8/8类别序列')
        pick = rng.randrange(total)
        for kind, ways, next_same, next_f in choices:
            if pick < ways:
                result.append(kind)
                remaining[kind] -= 1
                prev, same_run, f_run = kind, next_same, next_f
                break
            pick -= ways
    return result


def generate_block(n: int, scored_trials: int, matches: int,
                   rng: random.Random, words=None):
    """仅N个启动词+24个计分词，8匹配/8邻近诱饵/8其他非匹配。

    优化点：避免连续未见新词、限制不必要的连续相同词、避免F答案
    连续堆积；其他非匹配优先从本序列已出现的词中选取，只有为了
    引入适量词汇或在旧词不满足lag约束时才引入新词。
    不进行10词预先呈现，不改变N-back准确匹配的定义。
    """
    if not 1 <= n <= 6:
        raise ValueError('N必须在1至6之间')
    if scored_trials != 24 or matches != 8:
        raise ValueError('当前版本固定每区块24计分、8匹配、8诱饵、8其他不匹配')
    available = list(words if words is not None else WORDS)
    if len(set(available)) < 10:
        raise ValueError('总词库至少需要10个互异词')
    pool = available if len(available) == 10 else rng.sample(available, 10)
    if len(set(pool)) != 10:
        raise ValueError('每区块10个候选词必须互异')
    pool_field = '|'.join(pool)
    # 1-back需要逐步引入更多词才能形成合法的诱饵；4–6-back则
    # 已由N个启动词建立了多种旧词，严格减少陌生词计分试次。
    max_new_scored = 8 - n
    min_distinct = 8
    max_occurrences = 9

    for attempt in range(600):
        types = _category_schedule(n, rng)
        sequence = rng.sample(pool, n)
        rows = [dict(trial_index=i+1, scored=False, word=w, is_match=False,
                     is_lure=False, trial_type='warmup', lure_lag='',
                     seen_before=False, correct_key='', candidate_pool=pool_field)
                for i,w in enumerate(sequence)]
        new_scored = 0
        prev_new = False
        success = True
        for kind in types:
            i = len(sequence)
            target = sequence[i-n]
            nearby = [(sequence[i-lag], lag) for lag in (n-1,n+1)
                      if lag >= 1 and i >= lag and sequence[i-lag] != target]
            seen = set(sequence)
            counts = {w: sequence.count(w) for w in seen}
            if kind == 'match':
                possibilities = [(target, '')]
            elif kind == 'lure':
                possibilities = nearby
            else:
                forbidden = {target} | {sequence[i-lag] for lag in (n-1,n+1)
                                        if lag >= 1 and i >= lag}
                possibilities = [(w, '') for w in pool if w not in forbidden]

            def legal(w):
                if counts.get(w, 0) >= max_occurrences:
                    return False
                if len(sequence) >= 2 and sequence[-1] == sequence[-2] == w:
                    return False
                # 除1-back真正匹配、2-back的lag1诱饵外，不让同一词连续出现。
                if sequence[-1] == w and not (
                    (n == 1 and kind == 'match') or
                    (n == 2 and kind == 'lure' and any(a == w and lag == 1 for a,lag in nearby))
                ):
                    return False
                # 4–6-back避免两词间的无目的近距重复。
                if n >= 4 and len(sequence) >= 2 and sequence[-2] == w:
                    return False
                # 禁止连续计分新词：杜绝ABCD接着EFGH的易排除片段。
                if w not in seen and (prev_new or new_scored >= max_new_scored):
                    return False
                return True

            possibilities = [(w, lag) for w, lag in possibilities if legal(w)]
            if not possibilities:
                success = False
                break
            if kind == 'other_nonmatch':
                old = [(w, lag) for w, lag in possibilities if w in seen]
                fresh = [(w, lag) for w, lag in possibilities if w not in seen]
                # 前半段在确有必要时少量引入新词；其余优先旧词非匹配。
                need_diversity = (len(seen) < min_distinct and
                                  new_scored < max_new_scored)
                remaining_other = sum(t == 'other_nonmatch' for t in types[len(rows)-n:])
                missing_new = max(0, min_distinct - len(seen))
                chance = missing_new / max(1, remaining_other + 1)
                if fresh and (not old or (need_diversity and rng.random() < max(.65, chance))):
                    possibilities = fresh
                elif old:
                    possibilities = old
            # 优先选择此前出现次数少的词，减少某个词短时间内反复刷屏。
            weights = [max(1, 7-counts.get(w, 0))**2 for w, _ in possibilities]
            pick = rng.randrange(sum(weights))
            choice = possibilities[-1]
            for item, weight in zip(possibilities, weights):
                if pick < weight:
                    choice = item
                    break
                pick -= weight
            w, lag = choice
            is_new = w not in seen
            if is_new: new_scored += 1
            prev_new = is_new
            sequence.append(w)
            rows.append(dict(trial_index=i+1, scored=True, word=w,
                             is_match=(kind == 'match'), is_lure=(kind == 'lure'),
                             trial_type=kind, lure_lag=lag,
                             seen_before=not is_new,
                             correct_key='j' if kind == 'match' else 'f',
                             candidate_pool=pool_field))
        if not success or len(set(sequence)) < min_distinct:
            continue
        if sum(not t['seen_before'] for t in rows if t['scored']) > max_new_scored:
            continue
        for i, t in enumerate(rows):
            if not t['scored']:
                continue
            match = t['word'] == rows[i-n]['word']
            near = {lag for lag in (n-1,n+1) if lag >= 1 and i >= lag
                    and t['word'] == rows[i-lag]['word']}
            if match != t['is_match']:
                raise AssertionError('计分词与N-back目标位置不一致')
            if t['trial_type'] == 'lure' and (match or t['lure_lag'] not in near):
                raise AssertionError('诱饵不满足N±1非目标位置要求')
            if t['trial_type'] == 'other_nonmatch' and (match or near):
                raise AssertionError('其他非匹配包含未标注诱饵')
        if {kind: sum(t['trial_type'] == kind for t in rows)
            for kind in ('match','lure','other_nonmatch')} == {
                'match': 8, 'lure': 8, 'other_nonmatch': 8
            }:
            return rows
    raise RuntimeError(f'{n}-back在600次尝试后未生成满足全部约束的词序列')


def distractor_pair(target_word: str, rng: random.Random, words=None):
    pool = list(words if words is not None else WORDS)
    pair = rng.sample([w for w in pool if w != target_word], 2)
    return pair[0], pair[1]


def signal_detection_metrics(trials):
    """Scored-trial metrics with log-linear correction for d-prime."""
    rows = [x for x in trials if x.get("scored", True)]
    targets = [x for x in rows if x["is_match"]]
    non_targets = [x for x in rows if not x["is_match"]]
    hit = sum(x.get("response_key") == "j" for x in targets)
    false_alarm = sum(x.get("response_key") == "j" for x in non_targets)
    miss = sum(x.get("response_key") != "j" for x in targets)
    correct_reject = sum(x.get("response_key") == "f" for x in non_targets)
    total = len(rows)
    correct = hit + correct_reject
    hit_rate = hit / len(targets) if targets else float("nan")
    fa_rate = false_alarm / len(non_targets) if non_targets else float("nan")
    balanced_acc = (hit_rate + 1 - fa_rate) / 2 if targets and non_targets else float("nan")
    if targets and non_targets:
        adj_hit = (hit + .5) / (len(targets) + 1)
        adj_fa = (false_alarm + .5) / (len(non_targets) + 1)
        z = NormalDist().inv_cdf
        dprime = z(adj_hit) - z(adj_fa)
    else:
        dprime = float("nan")
    rts = [float(x["rt"]) for x in rows if x.get("correct") and x.get("rt") not in (None, "")]
    return dict(scored_trials=total, n_targets=len(targets), n_nontargets=len(non_targets),
                hits=hit, misses=miss, false_alarms=false_alarm, correct_rejections=correct_reject,
                accuracy=correct / total if total else float("nan"), hit_rate=hit_rate,
                false_alarm_rate=fa_rate, balanced_accuracy=balanced_acc, dprime=dprime,
                mean_correct_rt=sum(rts)/len(rts) if rts else float("nan"),
                n_correct_rt=len(rts))



def joint_level_decision(blocks_by_condition: dict, cfg: dict) -> dict:
    """任一干扰条件的两区块合计准确率达到阈值则升级。

    两条件各2个24计分区块（各48个试次），分别统计；
    无干扰或有干扰任一准确率 >= 90% 即可升级。
    联合准确率仅作描述统计，不参与升级。
    """
    if set(blocks_by_condition) != {'with','without'}:
        raise ValueError('每个N等级必须同时测试有干扰和无干扰')
    output={}
    all_correct=all_total=0
    for cond in ('without','with'):
        blocks=blocks_by_condition[cond]
        if len(blocks) != int(cfg['repeat_blocks']):
            raise ValueError('条件缺少重复区块')
        total=sum(int(b['scored_trials']) for b in blocks)
        correct=sum(int(b['hits']) + int(b['correct_rejections']) for b in blocks)
        if total<=0 or correct>total:
            raise ValueError('区块得分数据不合理')
        output[f'{cond}_correct']=correct
        output[f'{cond}_scored']=total
        output[f'{cond}_accuracy']=correct/total
        all_correct+=correct
        all_total+=total
    # 对于两个条件等量试次，这等价于两条件正确率取算术平均。
    if output['with_scored'] != output['without_scored']:
        raise ValueError('两个条件试次数不同，无法直接等权平均；请检查区块设置')
    output['combined_correct']=all_correct
    output['combined_scored']=all_total
    output['combined_accuracy']=all_correct/all_total
    output['upgrade_threshold']=float(cfg['upgrade_accuracy_threshold'])
    output['without_pass']=output['without_accuracy']>=output['upgrade_threshold']
    output['with_pass']=output['with_accuracy']>=output['upgrade_threshold']
    output['level_pass']=output['without_pass'] or output['with_pass']
    return output

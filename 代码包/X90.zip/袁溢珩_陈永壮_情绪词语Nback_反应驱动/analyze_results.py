# -*- coding: utf-8 -*-
"""任一条件90%升级版本：按情绪输出最高N和每个N两干扰条件准确率的描述统计。"""
import csv
import statistics
from pathlib import Path
from collections import defaultdict
ROOT=Path(__file__).resolve().parent
DATA=ROOT/'data'

def read_csv(path):
    with path.open(newline='',encoding='utf-8-sig') as f:
        return list(csv.DictReader(f))

def save_csv(path,rows,fields):
    with path.open('w',newline='',encoding='utf-8-sig') as f:
        writer=csv.DictWriter(f,fieldnames=fields)
        writer.writeheader(); writer.writerows(rows)

def main():
    DATA.mkdir(exist_ok=True)
    individual=[];levels=[];groups=defaultdict(list)
    for folder in sorted(DATA.iterdir()):
        if not folder.is_dir() or not (folder/'summary.csv').exists() or not (folder/'level_results.csv').exists():
            continue
        s=read_csv(folder/'summary.csv')
        if len(s)!=3 or {x['emotion'] for x in s}!={'positive','negative','neutral'}:
            continue
        if any(x.get('both_completed','').lower() not in ('true','1') for x in s):
            continue
        l=read_csv(folder/'level_results.csv')
        individual.extend([{'session':folder.name,**x} for x in s])
        levels.extend([{'session':folder.name,**x} for x in l])
        for x in s:
            groups[x['emotion']].append(int(x['highest_either_n']))
    if not individual:
        print('暂无完整的新版实验数据（需要summary.csv及level_results.csv）')
        return
    save_csv(DATA/'individual_either_max.csv',individual,list(individual[0]))
    save_csv(DATA/'individual_level_accuracy.csv',levels,list(levels[0]))
    names={'positive':'积极','neutral':'中性','negative':'消极'}
    out=[]
    for emotion in ('positive','neutral','negative'):
        x=groups[emotion]
        out.append({'emotion':emotion,'emotion_zh':names[emotion], 'n_participants':len(x),
                    'mean_highest_either_n':round(statistics.mean(x),3),
                    'median_highest_either_n':statistics.median(x),
                    'sd_highest_either_n':round(statistics.stdev(x),3) if len(x)>1 else ''})
    save_csv(DATA/'group_either_max_descriptive.csv',out,list(out[0]))
    print(f'纳入{len(individual)//3}次完整实验；已输出个体最高N、每级两条件准确率、三情绪的描述统计。')
if __name__=='__main__':main()

# -*- coding: utf-8 -*-
"""情绪整体分组的词语N-back：每种情绪单独从1-back升级至最高6-back。

PsychoPy Coder 或 Builder 共用此程序；不包含练习、情绪评分、注意探针或模式切换。
"""
from __future__ import annotations

import csv
import hashlib
import itertools
import json
import platform
import random
import re
import traceback
import wave
from datetime import datetime
from pathlib import Path

from nback_logic import (
    validate_config, generate_block, distractor_pair, WORDS,
    signal_detection_metrics, joint_level_decision,
)

ROOT = Path(__file__).resolve().parent
VERSION = 'response_contingent_either90_6back_10words_8-8-8_seqopt_rt3_fix07_20261123'
EMOTIONS = ('positive', 'neutral', 'negative')
EMOTION_ZH = {'positive':'积极', 'neutral':'中性', 'negative':'消极'}
DISTRACTOR_ZH = {'with':'有干扰', 'without':'无干扰'}

TRIAL_FIELDS = "participant order_index session emotion emotion_zh distractor_level distractor_zh n repetition trial_index scored word trial_type lure_lag seen_before candidate_pool upper_distractor lower_distractor is_match is_lure correct_key response_key correct rt_seconds word_exposure_seconds trial_elapsed_seconds image_set timestamp".split()
BLOCK_FIELDS = "participant order_index session emotion emotion_zh distractor_level distractor_zh n repetition candidate_pool match_trials lure_trials other_nonmatch_trials scored_trials n_targets n_nontargets hits misses false_alarms correct_rejections accuracy hit_rate false_alarm_rate balanced_accuracy dprime mean_correct_rt n_correct_rt response_rate block_accuracy_ge90".split()
LEVEL_FIELDS = "participant order_index session emotion emotion_zh n without_correct without_scored without_accuracy with_correct with_scored with_accuracy combined_correct combined_scored combined_accuracy upgrade_threshold without_pass with_pass level_pass next_n timestamp".split()
SESSION_FIELDS = "participant order_index session emotion emotion_zh distractor_level distractor_zh highest_either_n last_tested_n accuracy_at_last_tested_n accuracy_at_highest_either_n reached_test_ceiling timestamp".split()
SUMMARY_FIELDS = "participant order_index emotion emotion_zh emotion_block highest_either_n last_tested_n combined_accuracy_at_last_n without_accuracy_at_last_n with_accuracy_at_last_n reached_test_ceiling both_completed".split()
IMAGE_FIELDS = "participant session emotion stage n sequence image_path duration_seconds timestamp".split()
AUDIO_FIELDS = "participant session emotion emotion_zh stage n audio_path audio_duration_seconds planned_image_duration_seconds actual_picture_elapsed_seconds timestamp".split()
STAGE_FIELDS = "participant order_index emotion_block emotion stage n distractor repetition timestamp".split()
CONDITION_FIELDS = "participant order_index emotion emotion_zh emotion_block distractor_level distractor_zh highest_either_n last_tested_n accuracy_at_last_tested_n accuracy_at_highest_either_n reached_test_ceiling timestamp".split()


class StopExperiment(Exception):
    """用户按ESC结束。"""


def load_config():
    with (ROOT / 'config.json').open('r', encoding='utf-8') as f:
        cfg = json.load(f)
    validate_config(cfg)
    return cfg


def save_csv_row(path, fields, row):
    path.parent.mkdir(parents=True, exist_ok=True)
    new_file = not path.exists() or path.stat().st_size == 0
    with path.open('a', newline='', encoding='utf-8-sig') as f:
        writer = csv.DictWriter(f, fieldnames=fields, extrasaction='ignore')
        if new_file:
            writer.writeheader()
        writer.writerow({k: row.get(k, '') for k in fields})
        f.flush()


def choose_emotion_order(pid):
    """若被试编号以数字结尾，顺序按编号 mod 6；其余由稳定哈希分配。"""
    m = re.search(r'(\d+)$', pid)
    if m:
        return int(m.group(1)) % 6
    return int.from_bytes(hashlib.sha256(pid.encode('utf-8')).digest()[:4], 'big') % 6


def build_schedule(order_index):
    """返回三种情绪的完整区块顺序；每种情绪只出现一次。"""
    return list(itertools.permutations(EMOTIONS))[order_index]


def distraction_order(order_index, emotion_block, n):
    """在每个N等级下平衡先测有/无干扰，且不跨情绪切换。"""
    if (order_index + emotion_block + n) % 2:
        return ('without', 'with')
    return ('with', 'without')


def stage_row(paths, emotion_block, emotion, stage, n='', distractor='', repetition=''):
    save_csv_row(paths['stage_log'], STAGE_FIELDS, {
        'participant':paths['participant'], 'order_index':paths['order_index'],
        'emotion_block':emotion_block, 'emotion':emotion, 'stage':stage,
        'n':n, 'distractor':distractor, 'repetition':repetition,
        'timestamp':datetime.now().isoformat(timespec='seconds'),
    })


def get_images(emotion):
    found = sorted((ROOT/'stimuli'/emotion).glob('*.jpg'))
    if len(found) < 4:
        raise FileNotFoundError(f'{emotion} 类别中至少需要4张jpg图片。')
    return found


def get_audio_path(emotion):
    path = ROOT / 'stimuli' / 'audio' / f'{emotion}_24s.wav'
    if not path.is_file():
        raise FileNotFoundError(f'缺少情绪诱导音频：{path}')
    return path


def check_audio_duration(cfg):
    """只允许音频与图片组时长匹配，防止改图片时长后声音提前结束。"""
    expected = float(cfg['emotion_image_seconds']) * int(cfg['emotion_images_per_induction'])
    for emotion in EMOTIONS:
        path = get_audio_path(emotion)
        with wave.open(str(path), 'rb') as wf:
            actual = wf.getnframes() / wf.getframerate()
            if wf.getnchannels() != 2 or wf.getsampwidth() != 2:
                raise ValueError(f'音频应为16位双声道WAV：{path}')
        if abs(actual - expected) > 0.02:
            raise ValueError(
                f'{emotion} 音频长度{actual:.3f}s，与情绪图片{expected:.3f}s不匹配。'
                '请更新音频后再修改图片数量或时长。')
    return expected


class UI:
    def __init__(self, cfg, existing_window=None):
        from psychopy import visual, core, event, sound
        self.visual, self.core, self.event = visual, core, event
        self.sound = sound
        self.current_audio = None
        self.cfg = cfg
        self.owns_window = existing_window is None
        self.font = cfg.get('font_override') or {
            'Windows': 'Microsoft YaHei', 'Darwin': 'PingFang SC',
            'Linux': 'Noto Sans CJK SC',
        }.get(platform.system(), 'Arial Unicode MS')
        self.win = existing_window or visual.Window(
            size=(cfg['window_width'],cfg['window_height']),
            fullscr=bool(cfg['fullscreen']), units='height',
            color=(-.83,-.85,-.89), allowGUI=True, waitBlanking=True,
        )
        self.head = visual.TextStim(self.win, text='', font=self.font, pos=(0,.29),
                                    height=.053, color='#F0F3F9', bold=True, wrapWidth=1.4)
        self.body = visual.TextStim(self.win, text='', font=self.font, pos=(0,.02),
                                    height=.039, color='#E6ECF4', wrapWidth=1.4, alignText='center')
        self.foot = visual.TextStim(self.win, text='', font=self.font, pos=(0,-.35),
                                    height=.025, color='#AFBCD0', wrapWidth=1.45)
        # 所有目标词与上下无关词：字体、字号、粗细、颜色完全一致。
        # 唯一可预测的目标区分线索为固定的屏幕中央位置。
        word_style = dict(font=self.font, height=.091, bold=True, color='#F5F5F5')
        self.center = visual.TextStim(self.win, text='', pos=(0, 0), **word_style)
        self.upper = visual.TextStim(self.win, text='', pos=(0, .20), **word_style)
        self.lower = visual.TextStim(self.win, text='', pos=(0, -.20), **word_style)
        self.fix = visual.TextStim(self.win, text='+', font=self.font, pos=(0,0),
                                   height=.070, color='#BDC9DB')
        self.feedback = visual.TextStim(self.win, text='', font=self.font, pos=(0,0),
                                        height=.096, bold=True, color='#20D473')
        self.photo = visual.ImageStim(self.win, image=str(get_images('neutral')[0]), pos=(0,0), size=(1.44,.81),
                                      units='height', interpolate=True)
        # 预加载三段音频，避免图片播放时再读取音频而影响呈现同步。
        self.audio_tracks = {
            emotion: sound.Sound(str(get_audio_path(emotion)),
                                 stereo=True, volume=float(cfg['emotion_audio_volume']))
            for emotion in EMOTIONS
        }

    def check_escape(self):
        if self.event.getKeys(keyList=['escape']):
            raise StopExperiment('ESC')

    def page(self, title, text, footer='按空格继续'):
        self.event.clearEvents(eventType='keyboard')
        self.head.text, self.body.text, self.foot.text = title, text, footer
        while True:
            self.head.draw(); self.body.draw(); self.foot.draw()
            self.win.flip()
            keys = self.event.getKeys(keyList=['space','escape'])
            if 'escape' in keys:
                raise StopExperiment('ESC')
            if 'space' in keys:
                return

    def rest(self, seconds):
        if seconds <= 0: return
        clock = self.core.Clock()
        while clock.getTime() < seconds:
            self.head.text = '请稍作休息'
            self.body.text = '下一组任务即将开始'
            self.foot.text = ''
            self.head.draw(); self.body.draw(); self.win.flip()
            self.check_escape()

    def pictures(self, paths, duration, emotion):
        """情绪音乐在第一张图片翻屏时启动；全部4张播完立即停止。

        按Esc也会在finally中停止声音。屏幕持续时间由图片控制，
        不会等待音频播放完成后才进入下一阶段。
        """
        self.event.clearEvents(eventType='keyboard')
        track = self.audio_tracks[emotion]
        track.stop()  # 确保每次新的N等级从音频第0秒播放
        self.current_audio = track
        clock = self.core.Clock()
        total_duration = len(paths) * duration
        first = True
        shown_index = None
        try:
            # 整组图片使用同一时钟，避免逐张重置时钟累积额外等待。
            while first or clock.getTime() < total_duration:
                elapsed = clock.getTime()
                image_index = min(int(elapsed / duration), len(paths)-1)
                if image_index != shown_index:
                    self.photo.image = str(paths[image_index])
                    shown_index = image_index
                self.photo.draw()
                if first:
                    # 第一张图片翻屏时触发对应情绪的24秒音频。
                    self.win.callOnFlip(track.play)
                self.win.flip()
                if first:
                    clock.reset()
                    first = False
                self.check_escape()
        finally:
            track.stop()
            self.current_audio = None
        self.last_picture_elapsed_seconds = round(float(clock.getTime()), 4)
        return self.last_picture_elapsed_seconds

    def fixation(self, seconds):
        clock = self.core.Clock()
        self.event.clearEvents(eventType='keyboard')
        while clock.getTime() < seconds:
            self.fix.draw(); self.win.flip(); self.check_escape()

    def word_trial(self, word, upper, lower, scored, correct_key):
        """反应驱动式词语试次：按键即反馈，不强制凑满反应窗。

        - 中央词最多显示 word_visible_seconds（默认1.0秒），随后若未按键显示十字；
        - 首次 F/J（不超过 trial_total_seconds=3.0秒）锁定回答和RT，
          下一次刷新即居中显示 Correct/Wrong，持续 feedback_seconds=0.5秒；
        - 超过反应截止仍未应答，记录漏答并显示红色 Wrong；
        - 不计分的前N个启动词仅显示1.0秒，不记录答案、不反馈；
        - 本函数结束后由 run_block() 统一显示0.7秒注视十字。

        注意：这是有意采用的反应驱动式SOA，非固定SOA。按键越早，
        下一个单词也会更早出现。feedback_seconds不计入RT。
        """
        visible_sec = float(self.cfg['word_visible_seconds'])
        deadline_sec = float(self.cfg['trial_total_seconds'])
        feedback_sec = float(self.cfg['feedback_seconds'])
        self.event.clearEvents(eventType='keyboard')
        clock = self.core.Clock()
        response, rt = '', ''
        feedback_started = None
        feedback_correct = False
        word_end_at = None

        # 第一次翻屏显示目标词后才重置计时，避免把准备绘图时间算入RT。
        self.center.text = word
        self.center.draw()
        if upper:
            self.upper.text, self.lower.text = upper, lower
            self.upper.draw(); self.lower.draw()
        self.win.flip()
        clock.reset()
        while True:
            elapsed = clock.getTime()
            for key, timestamp in self.event.getKeys(
                    keyList=['f', 'j', 'escape'], timeStamped=clock):
                if key == 'escape':
                    raise StopExperiment('ESC')
                if (scored and feedback_started is None
                        and 0 <= float(timestamp) <= deadline_sec):
                    response, rt = key, round(float(timestamp), 4)
                    feedback_correct = key == correct_key
                    feedback_started = clock.getTime()
                    break

            elapsed = clock.getTime()
            if scored and feedback_started is None and elapsed >= deadline_sec:
                feedback_started = elapsed
                feedback_correct = False

            if scored:
                if feedback_started is not None and elapsed - feedback_started >= feedback_sec:
                    break
                if feedback_started is not None:
                    self.feedback.text = 'Correct' if feedback_correct else 'Wrong'
                    self.feedback.color = '#20D473' if feedback_correct else '#FF4D5A'
                    self.feedback.pos = (0, 0)
                    self.feedback.draw()
                    drawing_word = False
                elif elapsed < visible_sec:
                    self.center.draw()
                    if upper:
                        self.upper.draw(); self.lower.draw()
                    drawing_word = True
                else:
                    self.fix.draw()
                    drawing_word = False
            else:
                if elapsed >= visible_sec:
                    break
                self.center.draw()
                if upper:
                    self.upper.draw(); self.lower.draw()
                drawing_word = True

            self.win.flip()
            # 从第一次实际改变画面的翻屏后测量词语暴露时间。
            if not drawing_word and word_end_at is None:
                word_end_at = clock.getTime()

        if word_end_at is None:
            word_end_at = clock.getTime()
        self.last_trial_timing = {
            'word_exposure_seconds': round(float(word_end_at), 4),
            'trial_elapsed_seconds': round(float(clock.getTime()), 4),
        }
        # 清空本试次反馈期间的F/J，不能影响下一试次。
        self.event.clearEvents(eventType='keyboard')
        return response, rt

    def close(self):
        if self.current_audio is not None:
            self.current_audio.stop()
            self.current_audio = None
        if self.owns_window:
            self.win.close()
            self.core.quit()


def participant_prompt():
    from psychopy import gui
    form={'被试编号':'001'}
    dialog=gui.DlgFromDict(dictionary=form, title='词语 N-back 实验', order=['被试编号'])
    if not dialog.OK: return None
    return form['被试编号']


def normalized_pid(raw):
    pid=re.sub(r'[^A-Za-z0-9_-]', '_', str(raw).strip())[:40]
    if not pid: raise ValueError('被试编号不能为空')
    return pid


def record_images(ui, rng, paths, emotion, session_idx, stage='initial', count=None, duration=None, n=1):
    cfg=ui.cfg
    count = int(count if count is not None else cfg['emotion_images_per_induction'])
    duration = float(duration if duration is not None else cfg['emotion_image_seconds'])
    images=get_images(emotion)
    # 不重复取样并随机排序；同情绪池中的相似构图仅作为课程实验用示例刺激。
    chosen=rng.sample(images, k=min(count,len(images)))
    for i,p in enumerate(chosen,1):
        save_csv_row(paths['image_log'],IMAGE_FIELDS,{
            'participant':paths['participant'], 'session':session_idx,'emotion':emotion,
            'stage':stage,'n':n,'sequence':i,'image_path':str(p.relative_to(ROOT)),
            'duration_seconds':duration,'timestamp':datetime.now().isoformat(timespec='seconds')})
    actual_elapsed = ui.pictures(chosen, duration, emotion)
    save_csv_row(paths['audio_log'], AUDIO_FIELDS, {
        'participant':paths['participant'], 'session':session_idx,
        'emotion':emotion, 'emotion_zh':EMOTION_ZH[emotion],
        'stage':stage, 'n':n,
        'audio_path':str(get_audio_path(emotion).relative_to(ROOT)),
        'audio_duration_seconds':count * duration,
        'planned_image_duration_seconds':count * duration,
        'actual_picture_elapsed_seconds':actual_elapsed,
        'timestamp':datetime.now().isoformat(timespec='seconds'),
    })
    return ','.join(p.name for p in chosen)


def run_block(ui,rng,paths,session_idx,emotion,distraction,n,rep,image_set):
    cfg=ui.cfg
    candidate_pool=rng.sample(WORDS, int(cfg['candidate_words_per_block']))
    ts=generate_block(n,int(cfg['block_scored_trials']),int(cfg['matches_per_block']),rng,words=candidate_pool)
    logged=[]
    for t in ts:
        ui.fixation(float(cfg['fixation_seconds']))
        upper,lower=distractor_pair(t['word'],rng,words=candidate_pool) if distraction=='with' else ('','')
        response,rt=ui.word_trial(t['word'],upper,lower,t['scored'],t['correct_key'])
        correct=(response==t['correct_key']) if t['scored'] else ''
        if t['scored']:
            logged.append({**t,'response_key':response,'correct':correct,'rt':rt})
        save_csv_row(paths['trials'],TRIAL_FIELDS,{
            'participant':paths['participant'],'order_index':paths['order_index'],
            'session':session_idx,'emotion':emotion,'emotion_zh':EMOTION_ZH[emotion],
            'distractor_level':distraction,'distractor_zh':DISTRACTOR_ZH[distraction],
            'n':n,'repetition':rep,'trial_index':t['trial_index'],
            'scored':t['scored'],'word':t['word'],
            'trial_type':t['trial_type'],'lure_lag':t['lure_lag'],
            'seen_before':t['seen_before'],'candidate_pool':t['candidate_pool'],
            'upper_distractor':upper,'lower_distractor':lower,
            'is_match':t['is_match'] if t['scored'] else '',
            'is_lure':t['is_lure'] if t['scored'] else '',
            'correct_key':t['correct_key'],'response_key':response,
            'correct':correct,'rt_seconds':rt,
            'word_exposure_seconds':getattr(ui, 'last_trial_timing', {}).get('word_exposure_seconds', ''),
            'trial_elapsed_seconds':getattr(ui, 'last_trial_timing', {}).get('trial_elapsed_seconds', ''),
            'image_set':image_set,
            'timestamp':datetime.now().isoformat(timespec='seconds'),
        })
    m=signal_detection_metrics(logged)
    m['response_rate']=sum(bool(x['response_key']) for x in logged)/len(logged)
    # 该区块是否达到90%仅作描述；升级只看同N下任一干扰条件两个区块的准确率是否达标。
    meets=(m['accuracy']>=float(cfg['upgrade_accuracy_threshold']))
    save_csv_row(paths['blocks'],BLOCK_FIELDS,{
        'participant':paths['participant'],'order_index':paths['order_index'],
        'session':session_idx,'emotion':emotion,'emotion_zh':EMOTION_ZH[emotion],
            'distractor_level':distraction,'distractor_zh':DISTRACTOR_ZH[distraction],
        'n':n,'repetition':rep, 'candidate_pool':'|'.join(candidate_pool),
        'match_trials':8,'lure_trials':8,'other_nonmatch_trials':8,
        **m, 'block_accuracy_ge90':meets,
    })
    return m


def block_description(n, emotion_block):
    return (f'词语任务 · 第 {emotion_block}/3 段 · {n}-back',
            f'判断中央单词是否与前面第 {n} 个单词相同：相同按 J，不同按 F。\n'
            '如果上下方出现其他单词，请忽略，只看中央单词。\n'
            f'每个区块的前 {n} 个单词用于准备，不用按键；其后作答会显示对错反馈。')


def run_emotion_ladder(ui, rng, paths, emotion_block, emotion):
    """只在当前情绪内从1到6逐级测试，升级按该N的有/无干扰联合准确率。

    对每一个N，两个干扰条件各测两个完整区块（每区块24计分词）。
    计算无干扰48词的正确率和有干扰48词的正确率，两者等权平均。
    有干扰或无干扰任一条件正确率 >= 90% 则升级；均未达标时结束本情绪，开始下一情绪。
    每次升到新N之前重新进行同类别完整情绪图片诱导，结束后按空格开始。
    """
    cfg = ui.cfg
    level_rows = []
    highest = 0
    stage_row(paths, emotion_block, emotion, 'emotion_start')
    for n in range(1, int(cfg['max_n']) + 1):
        if n > 1:
            ui.rest(float(cfg['between_level_rest_seconds']))
        # 每一级（包括升级后的N）开始前重新完整播放本情绪的4张图片。
        stage_row(paths, emotion_block, emotion, 'induction_start', n)
        image_set = record_images(ui, rng, paths, emotion, emotion_block,
                                  stage='full_induction', n=n)
        stage_row(paths, emotion_block, emotion, 'induction_end', n)
        # 为避免刚看完图片就突然出现词语，保留独立准备页面。
        stage_row(paths, emotion_block, emotion, 'nback_ready_screen', n)
        ui.page(f'即将开始 {n}-back 任务',
                f'接下来进行 {n}-back 词语判断。\n'
                f'当前屏幕中间的目标词与前面第 {n} 个中间目标词相同按 J，不同按 F。\n'
                '若同时出现上、中、下三个词，请只判断最中间的词。',
                '准备好后，按空格开始')
        stage_row(paths, emotion_block, emotion, 'nback_ready_confirmed', n)
        stage_row(paths, emotion_block, emotion, 'level_start', n)

        blocks_by_condition = {}
        for distraction in distraction_order(paths['order_index'], emotion_block, n):
            blocks=[]
            condition_name=DISTRACTOR_ZH[distraction]
            condition_explain=('本组只呈现屏幕正中间的目标词。' if distraction=='without' else
                               '本组上、中、下同时出现三个相同字号的词。\n'
                               '请只看最中间的词；上下两个词不参与比较。')
            for rep in range(1,int(cfg['repeat_blocks'])+1):
                if rep>1:
                    ui.rest(float(cfg['between_block_rest_seconds']))
                stage_row(paths, emotion_block, emotion, 'block_ready_screen', n, distraction, rep)
                ui.page(f'{n}-back · {condition_name} · 第 {rep}/{cfg["repeat_blocks"]} 组',
                        f'接下来开始 {n}-back 的{condition_name}测试。\n'
                        f'{condition_explain}\n'
                        f'当前中间目标词与前面第 {n} 个中间目标词相同按 J，不同按 F。\n'
                        f'本组前 {n} 个词不计分、无需按键。',
                        '准备好后，按空格开始本组')
                stage_row(paths,emotion_block,emotion,'block_ready_confirmed',n,distraction,rep)
                if rep==1:
                    stage_row(paths,emotion_block,emotion,'condition_start',n,distraction)
                blocks.append(run_block(ui,rng,paths,emotion_block,emotion,
                                        distraction,n,rep,image_set))
            blocks_by_condition[distraction]=blocks
            stage_row(paths, emotion_block, emotion, 'condition_end', n, distraction)

        decision=joint_level_decision(blocks_by_condition, cfg)
        decision_row={
            'participant':paths['participant'],'order_index':paths['order_index'],
            'session':emotion_block,'emotion':emotion,'emotion_zh':EMOTION_ZH[emotion],
            'n':n,**decision,
            'next_n':n+1 if decision['level_pass'] and n<int(cfg['max_n']) else '',
            'timestamp':datetime.now().isoformat(timespec='seconds')}
        save_csv_row(paths['level_results'], LEVEL_FIELDS, decision_row)
        level_rows.append(decision_row)
        if decision['level_pass']:
            highest=n
            stage_row(paths,emotion_block,emotion,'level_pass',n)
        else:
            stage_row(paths,emotion_block,emotion,'level_fail',n)
        stage_row(paths,emotion_block,emotion,'level_end',n)
        if not decision['level_pass']:
            break

    last=level_rows[-1]
    passed_level=next((r for r in level_rows if r['n']==highest),None)
    ceiling=highest==int(cfg['max_n'])
    for distraction in ('without','with'):
        key=distraction+'_accuracy'
        result_row={
            'participant':paths['participant'],'order_index':paths['order_index'],
            'session':emotion_block,'emotion_block':emotion_block,
            'emotion':emotion,'emotion_zh':EMOTION_ZH[emotion],
            'distractor_level':distraction,'distractor_zh':DISTRACTOR_ZH[distraction],
            'highest_either_n':highest,'last_tested_n':last['n'],
            'accuracy_at_last_tested_n':last[key],
            'accuracy_at_highest_either_n':passed_level[key] if passed_level else '',
            'reached_test_ceiling':ceiling,'timestamp':datetime.now().isoformat(timespec='seconds')}
        save_csv_row(paths['sessions'],SESSION_FIELDS,result_row)
        save_csv_row(paths['condition_results'],CONDITION_FIELDS,result_row)
    stage_row(paths,emotion_block,emotion,'emotion_complete')
    return {'highest_either_n':highest,'last_level':last,'reached_test_ceiling':ceiling}


def run_experiment(participant_id=None, existing_window=None, show_intro=False, show_end=True):
    cfg=load_config()
    check_audio_duration(cfg)
    print(f"N-back program version: {VERSION}; emotion outer loop, either condition >=90%, max N={cfg['max_n']}")
    if participant_id is None:
        participant_id=participant_prompt()
        if participant_id is None: return False
    pid=normalized_pid(participant_id)
    order_index=choose_emotion_order(pid)
    stamp=datetime.now().strftime('%Y%m%d_%H%M%S_%f')
    rng_seed=int.from_bytes(hashlib.sha256(f'{pid}:{stamp}'.encode('utf-8')).digest()[:8],'big')
    rng=random.Random(rng_seed)
    out=ROOT/'data'/f'{pid}_{stamp}'
    out.mkdir(parents=True,exist_ok=True)
    paths={'participant':pid,'order_index':order_index}
    for name in ('trials','blocks','level_results','sessions','summary','condition_results','image_log','audio_log','stage_log'):
        paths[name]=out/f'{name}.csv'
    with (out/'run_manifest.json').open('w',encoding='utf-8') as f:
        json.dump({'participant':pid,'version':VERSION,'order_index':order_index,'seed':rng_seed,
                   'configuration':cfg,'stimuli_are_normed':False,
                   'order_rule':'each emotion fully 1..6 N, full reinduction before each N; either with or without >=90pct accuracy',
                   'emotion_order':list(build_schedule(order_index)),
                   'start_time':datetime.now().isoformat(timespec='seconds')},
                  f,ensure_ascii=False,indent=2)
    ui=None
    try:
        ui=UI(cfg,existing_window)
        # 简短的实验准备页；不恢复此前冗长的总体任务介绍。
        # Builder 通过 show_intro=False 调用本函数时仍然显示该准备页。
        stage_row(paths,0,'','experiment_ready_screen')
        ui.page('请被试准备实验',
                '准备好后按下空格键开始实验。',
                '')
        stage_row(paths,0,'','experiment_ready_confirmed')
        scores={}
        schedule=build_schedule(order_index)
        for emotion_block,emotion in enumerate(schedule,1):
            if emotion_block>1:
                ui.rest(float(cfg['between_emotion_rest_seconds']))
            # 本情绪从1-back逐级测试至联合准确率不达标，再切换情绪。
            scores[emotion]=run_emotion_ladder(ui,rng,paths,emotion_block,emotion)
            last=scores[emotion]['last_level']
            save_csv_row(paths['summary'],SUMMARY_FIELDS,{
                'participant':pid,'order_index':order_index,
                'emotion':emotion,'emotion_zh':EMOTION_ZH[emotion],
                'emotion_block':emotion_block,
                'highest_either_n':scores[emotion]['highest_either_n'],
                'last_tested_n':last['n'],
                'combined_accuracy_at_last_n':last['combined_accuracy'],
                'without_accuracy_at_last_n':last['without_accuracy'],
                'with_accuracy_at_last_n':last['with_accuracy'],
                'reached_test_ceiling':scores[emotion]['reached_test_ceiling'],
                'both_completed':True})
        if show_end:
            ui.page('实验完成','本次词语判断任务已结束。感谢参与。','按空格结束')
        return True
    except StopExperiment as e:
        (out/'stopped.txt').write_text(str(e),encoding='utf-8')
        return False
    except Exception:
        err=traceback.format_exc()
        (out/'error_traceback.txt').write_text(err,encoding='utf-8')
        print(err)
        raise
    finally:
        if ui is not None:
            ui.close()


if __name__=='__main__':
    run_experiment()

# -*- coding: utf-8 -*-
"""新词分散/正确性/反应策略回归测试，无 PsychoPy 依赖。"""
from collections import Counter
import random
from nback_logic import generate_block, WORDS


def main():
    trials_checked = 0
    for n in range(1, 7):
        for seed in range(12):
            seq = generate_block(n, 24, 8, random.Random((n << 21)+seed))
            assert len(seq) == n+24
            assert all(not row['scored'] for row in seq[:n])
            scored = seq[n:]
            assert all(row['scored'] for row in scored)
            assert Counter(row['trial_type'] for row in scored) == {
                'match':8,'lure':8,'other_nonmatch':8}
            assert len(set(row['word'] for row in seq)) == 8
            assert set(row['word'] for row in seq).issubset(set(WORDS))
            assert all(not (not a['seen_before'] and not b['seen_before'])
                       for a,b in zip(scored,scored[1:]))
            long_two_word_windows = sum(
                len({row['word'] for row in seq[i:i+6]}) <= 2
                for i in range(len(seq)-5))
            assert long_two_word_windows <= (2 if n <= 2 else 0), (
                n, seed, long_two_word_windows, '局部重复过量')
            assert all(not (a['word']==b['word']==c['word'])
                       for a,b,c in zip(seq,seq[1:],seq[2:]))
            assert all(not all(row['correct_key']=='f' for row in scored[i:i+5])
                       for i in range(len(scored)-4))
            assert all(not (a['trial_type']==b['trial_type']==c['trial_type'])
                       for a,b,c in zip(scored,scored[1:],scored[2:]))
            assert all(not (seq[i]['word'] == seq[i-1]['word'])
                       for i in range(1,len(seq))
                       if n>=3)
            for i,row in enumerate(scored, start=n):
                m=(seq[i]['word']==seq[i-n]['word'])
                lags={lag for lag in (n-1,n+1) if lag>=1 and i>=lag
                      and seq[i]['word']==seq[i-lag]['word']}
                assert row['is_match']==m
                assert row['correct_key']==('j' if m else 'f')
                assert row['is_lure']==(row['trial_type']=='lure')
                if row['trial_type']=='lure':
                    assert not m and row['lure_lag'] in lags
                elif row['trial_type']=='other_nonmatch':
                    assert not m and not lags
                assert row['seen_before']==any(seq[j]['word']==row['word'] for j in range(i))
            # 不依赖准确位置、只看是否见过的策略不能通过85%门槛。
            familiarity=sum(('j' if r['seen_before'] else 'f')==r['correct_key']
                            for r in scored)/24
            assert familiarity <= 16/24
            trials_checked+=24
        print(f'PASS {n}-back: 12 randomized blocks')
    print(f'PASS all: {6*12} blocks, {trials_checked} scored trials')

if __name__ == '__main__':
    main()
